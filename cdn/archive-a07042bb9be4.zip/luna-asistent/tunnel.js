/**
 * tunnel.js - Cloudflare Tunnel Manager
 * © Kazama Dev (Dhilzz) 2026
 */

const { spawn } = require('child_process');
const chalk     = require('chalk');

async function startTunnel(token) {
    if (!token) {
        console.log(chalk.yellow('[⚠️] Cloudflared token tidak ada, skip tunnel.'));
        return;
    }

    console.log(chalk.cyan('[🌐] Memulai Cloudflare Tunnel...'));

    const args = token.startsWith('eyJ')
        ? ['tunnel', '--no-autoupdate', 'run', '--token', token]
        : ['tunnel', '--no-autoupdate', '--url', `http://localhost:${global.port || 3000}`];

    const proc = spawn('cloudflared', args, { stdio: 'pipe' });

    proc.stdout.on('data', (data) => {
        const line = data.toString().trim();
        if (line.includes('trycloudflare.com') || line.includes('.cloudflare.com')) {
            const urlMatch = line.match(/https:\/\/[^\s]+/);
            if (urlMatch) {
                console.log(chalk.green(`[🌐] Tunnel URL: ${urlMatch[0]}`));
            }
        }
    });

    proc.stderr.on('data', (data) => {
        const line = data.toString().trim();
        if (line.includes('https://') && (line.includes('trycloudflare') || line.includes('.cloudflare'))) {
            const urlMatch = line.match(/https:\/\/[^\s]+/);
            if (urlMatch) console.log(chalk.green(`[🌐] Tunnel URL: ${urlMatch[0]}`));
        }
    });

    proc.on('close', (code) => {
        if (code !== 0) {
            console.log(chalk.yellow(`[⚠️] Tunnel ditutup (code ${code}). Restart dalam 5 detik...`));
            setTimeout(() => startTunnel(token), 5000);
        }
    });

    proc.on('error', (err) => {
        console.error(chalk.red(`[✗] Cloudflared error: ${err.message}`));
        console.log(chalk.yellow('[ℹ️] Pastikan cloudflared sudah terinstall: npm i -g cloudflared'));
    });

    return proc;
}

module.exports = { startTunnel };
