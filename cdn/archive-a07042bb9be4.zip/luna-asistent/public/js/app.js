/**
 * app.js - Luna Asistent Client JS
 * © Kazama Dev (Dhilzz) 2026
 */

// ===== Page Loader =====
window.addEventListener('load', () => {
    const loader = document.getElementById('page-loader');
    if (loader) {
        setTimeout(() => loader.classList.add('hidden'), 400);
    }
});

// ===== Luna UI - Custom Alert/Confirm/Toast =====
const Luna = {
    // Toast notification
    toast(message, type = 'info', duration = 3500) {
        const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            document.body.appendChild(container);
        }
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <span class="toast-icon">${icons[type] || 'ℹ️'}</span>
            <span>${message}</span>`;
        container.appendChild(toast);
        setTimeout(() => {
            toast.style.animation = 'toastOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    // Custom Alert
    alert(title, message, type = 'info') {
        return new Promise(resolve => {
            const icons = { info: '💬', success: '✅', error: '❌', warning: '⚠️' };
            const overlay = createOverlay(`
                <div class="luna-modal-icon">${icons[type]}</div>
                <div class="luna-modal-title">${title}</div>
                <div class="luna-modal-msg">${message}</div>
                <div class="luna-modal-actions">
                    <button class="btn btn-primary" id="luna-ok">OK</button>
                </div>`);
            overlay.querySelector('#luna-ok').onclick = () => {
                closeOverlay(overlay);
                resolve(true);
            };
        });
    },

    // Custom Confirm
    confirm(title, message, confirmText = 'Ya, Lanjutkan', cancelText = 'Batal') {
        return new Promise(resolve => {
            const overlay = createOverlay(`
                <div class="luna-modal-icon">❓</div>
                <div class="luna-modal-title">${title}</div>
                <div class="luna-modal-msg">${message}</div>
                <div class="luna-modal-actions">
                    <button class="btn btn-ghost" id="luna-cancel">${cancelText}</button>
                    <button class="btn btn-primary" id="luna-confirm">${confirmText}</button>
                </div>`);
            overlay.querySelector('#luna-confirm').onclick = () => {
                closeOverlay(overlay);
                resolve(true);
            };
            overlay.querySelector('#luna-cancel').onclick = () => {
                closeOverlay(overlay);
                resolve(false);
            };
        });
    },

    // Loading state
    loading(show = true, message = 'Memproses...') {
        let el = document.getElementById('luna-loading');
        if (show) {
            if (!el) {
                el = document.createElement('div');
                el.id = 'luna-loading';
                el.className = 'luna-overlay active';
                el.innerHTML = `
                    <div class="luna-modal" style="text-align:center;padding:32px 40px;">
                        <div class="spinner-bars" style="justify-content:center;margin-bottom:16px;">
                            <span></span><span></span><span></span><span></span><span></span>
                        </div>
                        <div style="color:var(--text-muted);font-size:14px;">${message}</div>
                    </div>`;
                document.body.appendChild(el);
            }
        } else {
            if (el) el.remove();
        }
    }
};

function createOverlay(content) {
    const overlay = document.createElement('div');
    overlay.className = 'luna-overlay';
    overlay.innerHTML = `<div class="luna-modal">${content}</div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('active'));
    return overlay;
}

function closeOverlay(overlay) {
    overlay.classList.remove('active');
    setTimeout(() => overlay.remove(), 300);
}

// ===== Sidebar Toggle =====
const sidebar   = document.querySelector('.sidebar');
const hamburger = document.querySelector('.hamburger');
const overlay   = document.querySelector('.sidebar-overlay') || (() => {
    const el = document.createElement('div');
    el.className = 'sidebar-overlay';
    document.body.appendChild(el);
    return el;
})();

if (hamburger) {
    hamburger.addEventListener('click', () => {
        sidebar?.classList.toggle('open');
        overlay.classList.toggle('show');
    });
    overlay.addEventListener('click', () => {
        sidebar?.classList.remove('open');
        overlay.classList.remove('show');
    });
}

// ===== Mobile Navbar =====
const navToggle = document.querySelector('.navbar-toggle');
const navLinks  = document.querySelector('.navbar-links');
if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
}

// ===== Welcome Overlay =====
const welcomeOverlay = document.getElementById('welcome-overlay');
if (welcomeOverlay) {
    setTimeout(() => {
        welcomeOverlay.style.opacity = '0';
        welcomeOverlay.style.transition = 'opacity 0.5s ease';
        setTimeout(() => welcomeOverlay.remove(), 500);
    }, 3000);
    welcomeOverlay.addEventListener('click', () => {
        welcomeOverlay.style.opacity = '0';
        setTimeout(() => welcomeOverlay.remove(), 500);
    });
}

// ===== Flash Messages Auto Dismiss =====
document.querySelectorAll('.alert[data-auto-dismiss]').forEach(el => {
    setTimeout(() => {
        el.style.opacity = '0';
        el.style.transition = 'opacity 0.3s';
        setTimeout(() => el.remove(), 300);
    }, 4000);
});

// ===== Toggle Password Visibility =====
document.querySelectorAll('.input-toggle[data-target]').forEach(btn => {
    btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.target);
        if (!input) return;
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.textContent = input.type === 'password' ? '👁️' : '🙈';
    });
});

// ===== Ajax Form Handler =====
document.querySelectorAll('form[data-ajax]').forEach(form => {
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = form.querySelector('[type=submit]');
        const originalText = btn?.innerHTML;
        if (btn) { btn.disabled = true; btn.innerHTML = '<div class="spinner-ring" style="width:18px;height:18px;border-width:2px;"></div>'; }

        try {
            const data = Object.fromEntries(new FormData(form));
            const res = await fetch(form.action, {
                method: form.method || 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const json = await res.json();

            if (json.success) {
                Luna.toast(json.message || 'Berhasil!', 'success');
                if (json.redirect) setTimeout(() => location.href = json.redirect, 1000);
            } else {
                Luna.toast(json.message || 'Gagal.', 'error');
            }
        } catch (err) {
            Luna.toast('Terjadi kesalahan.', 'error');
        } finally {
            if (btn) { btn.disabled = false; btn.innerHTML = originalText; }
        }
    });
});

// ===== Toggle Switch Handler =====
document.querySelectorAll('.toggle-switch[data-url]').forEach(sw => {
    const input = sw.querySelector('input');
    input?.addEventListener('change', async () => {
        try {
            const res = await fetch(sw.dataset.url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ value: input.checked })
            });
            const json = await res.json();
            if (json.success) {
                Luna.toast('Pengaturan disimpan!', 'success');
                if (sw.dataset.reload) setTimeout(() => location.reload(), 500);
            } else {
                input.checked = !input.checked;
                Luna.toast('Gagal menyimpan.', 'error');
            }
        } catch {
            input.checked = !input.checked;
            Luna.toast('Terjadi kesalahan.', 'error');
        }
    });
});

// ===== Copy to Clipboard =====
document.querySelectorAll('[data-copy]').forEach(btn => {
    btn.addEventListener('click', () => {
        const text = btn.dataset.copy || btn.previousElementSibling?.value || btn.textContent;
        navigator.clipboard.writeText(text).then(() => {
            Luna.toast('Disalin ke clipboard!', 'success', 2000);
        });
    });
});

// ===== Confirm Delete =====
document.querySelectorAll('[data-confirm]').forEach(btn => {
    btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const msg = btn.dataset.confirm || 'Yakin ingin melanjutkan?';
        const ok = await Luna.confirm('Konfirmasi', msg, 'Ya, Lanjutkan');
        if (ok) {
            if (btn.dataset.href) location.href = btn.dataset.href;
            else if (btn.type === 'submit') btn.form?.submit();
            else if (btn.dataset.action) {
                Luna.loading(true);
                fetch(btn.dataset.action, { method: 'DELETE' })
                    .then(r => r.json())
                    .then(json => {
                        Luna.loading(false);
                        if (json.success) {
                            Luna.toast('Berhasil dihapus!', 'success');
                            btn.closest('[data-remove]')?.remove();
                        } else Luna.toast(json.message || 'Gagal.', 'error');
                    })
                    .catch(() => { Luna.loading(false); Luna.toast('Error.', 'error'); });
            }
        }
    });
});

// ===== Format Currency =====
function formatRupiah(amount) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
}

// ===== Expose globally =====
window.Luna = Luna;
window.formatRupiah = formatRupiah;
