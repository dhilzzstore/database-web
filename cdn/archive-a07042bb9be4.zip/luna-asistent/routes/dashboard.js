/**
 * routes/dashboard.js - User Dashboard Routes
 * © Kazama Dev (Dhilzz) 2026
 */

const express  = require('express');
const router   = express.Router();
const { db }   = require('../core/firebase');
const { requireAuth, logActivity } = require('../core/middleware');
const path = require('path');
const fs   = require('fs');

// Semua route dashboard butuh auth
router.use(requireAuth);

// ========== Dashboard Home ==========
router.get('/', async (req, res) => {
    try {
        const user = req.user;
        const showWelcome = req.session.showWelcome || false;
        req.session.showWelcome = false;

        const now = new Date();
        const expiry = user.membershipExpiry
            ? new Date(user.membershipExpiry.toDate ? user.membershipExpiry.toDate() : user.membershipExpiry)
            : null;
        const daysLeft = expiry ? Math.max(0, Math.ceil((expiry - now) / (1000 * 60 * 60 * 24))) : 0;
        const isActive = expiry && expiry > now;

        // Ambil koneksi bot user
        const connectionsSnap = await db.collection('connections')
            .where('userId', '==', user.uid).get();
        const connections = connectionsSnap.docs.map(d => ({ id: d.id, ...d.data() }));

        const activeBot = connections.filter(c => c.status === 'connected').length;

        res.render('dashboard/index', {
            title: `Dashboard - ${global.siteName}`,
            user,
            daysLeft,
            isActive,
            expiry,
            connections,
            activeBot,
            showWelcome,
            page: 'dashboard'
        });
    } catch (e) {
        console.error(e);
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Connections ==========
router.get('/connections', async (req, res) => {
    try {
        const snap = await db.collection('connections')
            .where('userId', '==', req.user.uid).get();
        const connections = snap.docs.map(d => ({ id: d.id, ...d.data() }));

        res.render('dashboard/connections', {
            title: `Connections - ${global.siteName}`,
            user: req.user,
            connections,
            maxSlots: req.user.slots || global.defaultSlots,
            page: 'connections'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Connection Detail / Aktivasi ==========
router.get('/connections/:id', async (req, res) => {
    try {
        const doc = await db.collection('connections').doc(req.params.id).get();
        if (!doc.exists || doc.data().userId !== req.user.uid) {
            return res.status(404).render('errors/404', { title: '404' });
        }

        const connection = { id: doc.id, ...doc.data() };
        res.render('dashboard/connection-detail', {
            title: `Bot ${connection.slotNumber} - ${global.siteName}`,
            user: req.user,
            connection,
            page: 'connections'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Add Connection (Slot baru) ==========
router.post('/connections/add', async (req, res) => {
    try {
        const user = req.user;
        const snap = await db.collection('connections')
            .where('userId', '==', user.uid).get();

        if (snap.size >= (user.slots || global.defaultSlots)) {
            return res.json({ success: false, message: `Slot penuh! Maksimal ${user.slots} slot.` });
        }

        const slotNumber = snap.size + 1;
        const ref = await db.collection('connections').add({
            userId: user.uid,
            slotNumber,
            phoneNumber: null,
            status: 'inactive',
            createdAt: new Date(),
            lastActive: null,
            botName: `Bot Slot ${slotNumber}`
        });

        logActivity('bot', `Add connection slot ${slotNumber}`, user.uid);
        res.json({ success: true, id: ref.id });
    } catch (e) {
        res.json({ success: false, message: 'Gagal menambah koneksi.' });
    }
});

// ========== Config ==========
router.get('/config', async (req, res) => {
    try {
        // Ambil config bot user dari DB atau pakai default
        const snap = await db.collection('botConfigs')
            .where('userId', '==', req.user.uid).limit(1).get();
        const botCfg = snap.empty ? { ...global.botConfig } : snap.docs[0].data();

        res.render('dashboard/config', {
            title: `Config Bot - ${global.siteName}`,
            user: req.user,
            botCfg,
            page: 'config'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

router.post('/config', async (req, res) => {
    try {
        const { namaBot, footer, welcomeMessage, autoStatus, limitPerUser, limitPerGroup } = req.body;
        const configData = {
            userId: req.user.uid,
            namaBot: namaBot || 'Luna Asistent',
            footer: footer || '©Kazama-Dev',
            welcomeMessage: welcomeMessage === 'on',
            autoStatus: autoStatus === 'on',
            limitPerUser: parseInt(limitPerUser) || 15,
            limitPerGroup: parseInt(limitPerGroup) || 30,
            updatedAt: new Date()
        };

        const snap = await db.collection('botConfigs')
            .where('userId', '==', req.user.uid).limit(1).get();

        if (snap.empty) {
            await db.collection('botConfigs').add(configData);
        } else {
            await db.collection('botConfigs').doc(snap.docs[0].id).update(configData);
        }

        logActivity('bot', 'Update config', req.user.uid);
        res.json({ success: true, message: 'Config berhasil disimpan.' });
    } catch (e) {
        res.json({ success: false, message: 'Gagal menyimpan config.' });
    }
});

// ========== Info / Logs ==========
router.get('/info', async (req, res) => {
    try {
        // Ambil log aktivitas user
        const logDir = path.join(__dirname, '..', 'data', 'logs');
        let logs = [];

        const logTypes = ['bot', 'auth', 'payment'];
        for (const type of logTypes) {
            const logFile = path.join(logDir, `${type}.log`);
            if (fs.existsSync(logFile)) {
                const lines = fs.readFileSync(logFile, 'utf8')
                    .split('\n')
                    .filter(Boolean)
                    .map(l => { try { return JSON.parse(l); } catch { return null; } })
                    .filter(l => l && l.userId === req.user.uid);
                logs.push(...lines);
            }
        }

        logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        const recentLogs = logs.slice(0, 50);

        res.render('dashboard/info', {
            title: `Info & Log - ${global.siteName}`,
            user: req.user,
            logs: recentLogs,
            page: 'info'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== FAQ ==========
router.get('/faq', (req, res) => {
    res.render('dashboard/faq', {
        title: `FAQ - ${global.siteName}`,
        user: req.user,
        page: 'faq'
    });
});

// ========== Pricing ==========
router.get('/pricing', (req, res) => {
    res.render('dashboard/pricing', {
        title: `Upgrade - ${global.siteName}`,
        user: req.user,
        membership: global.membership,
        slotPrice: global.slotPrice,
        page: 'pricing'
    });
});

// ========== Referral ==========
router.get('/referral', async (req, res) => {
    try {
        const user = req.user;
        const refLink = `${global.baseUrl}/auth/register?ref=${user.referralCode}`;

        // Ambil daftar referral
        const snap = await db.collection('users')
            .where('referredBy', '==', user.uid).get();
        const referrals = snap.docs.map(d => ({
            name: d.data().name,
            createdAt: d.data().createdAt
        }));

        res.render('dashboard/referral', {
            title: `Referral - ${global.siteName}`,
            user,
            refLink,
            referrals,
            bonusDays: global.referralBonusDays,
            page: 'referral'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Response Kustom ==========
router.get('/response', async (req, res) => {
    try {
        const snap = await db.collection('customResponses')
            .where('userId', '==', req.user.uid).get();
        const responses = snap.docs.map(d => ({ id: d.id, ...d.data() }));

        res.render('dashboard/response', {
            title: `Custom Response - ${global.siteName}`,
            user: req.user,
            responses,
            page: 'response'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Analytics ==========
router.get('/analytics', async (req, res) => {
    try {
        // Ambil data analytics dari DB
        const snap = await db.collection('analytics')
            .where('userId', '==', req.user.uid)
            .orderBy('date', 'desc').limit(30).get();
        const analytics = snap.docs.map(d => d.data());

        res.render('dashboard/analytics', {
            title: `Analytics - ${global.siteName}`,
            user: req.user,
            analytics,
            page: 'analytics'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Broadcast ==========
router.get('/broadcast', async (req, res) => {
    const now = new Date();
    const expiry = req.user.membershipExpiry
        ? new Date(req.user.membershipExpiry.toDate ? req.user.membershipExpiry.toDate() : req.user.membershipExpiry)
        : null;
    const isPremium = expiry && expiry > now &&
        ['1month', '1year'].includes(req.user.membershipPlan);

    res.render('dashboard/broadcast', {
        title: `Broadcast - ${global.siteName}`,
        user: req.user,
        isPremium,
        page: 'broadcast'
    });
});

// ========== Command ==========
router.get('/command', async (req, res) => {
    res.render('dashboard/command', {
        title: `Command - ${global.siteName}`,
        user: req.user,
        page: 'command'
    });
});

// ========== Feedback / Report ==========
router.post('/feedback', async (req, res) => {
    try {
        const { type, subject, message } = req.body;
        await db.collection('feedbacks').add({
            userId: req.user.uid,
            userName: req.user.name,
            userEmail: req.user.email,
            type: type || 'feedback',
            subject,
            message,
            status: 'unread',
            createdAt: new Date()
        });
        logActivity('feedback', `Submit feedback: ${subject}`, req.user.uid);
        res.json({ success: true, message: 'Feedback berhasil dikirim.' });
    } catch (e) {
        res.json({ success: false, message: 'Gagal mengirim feedback.' });
    }
});

// ========== Profile Settings ==========
router.get('/profile', (req, res) => {
    res.render('dashboard/profile', {
        title: `Profil - ${global.siteName}`,
        user: req.user,
        page: 'profile'
    });
});

module.exports = router;

// ========== Profile POST ==========
router.post('/profile', requireAuth, async (req, res) => {
    try {
        const { name, username, email } = req.body;
        if (!name || !username) return res.json({ success: false, message: 'Nama dan username wajib diisi.' });

        // Cek username tidak duplikat
        if (username !== req.user.username) {
            const snap = await db.collection('users')
                .where('username', '==', username.toLowerCase()).limit(1).get();
            if (!snap.empty && snap.docs[0].id !== req.user.uid)
                return res.json({ success: false, message: 'Username sudah digunakan.' });
        }

        const updateData = { name, username: username.toLowerCase() };
        if (email && email !== req.user.email) {
            const snap = await db.collection('users').where('email','==',email.toLowerCase()).limit(1).get();
            if (!snap.empty && snap.docs[0].id !== req.user.uid)
                return res.json({ success: false, message: 'Email sudah digunakan.' });
            updateData.email = email.toLowerCase();
        }

        await db.collection('users').doc(req.user.uid).update(updateData);
        logActivity('auth', `Update profile`, req.user.uid);
        res.json({ success: true, message: 'Profil berhasil diperbarui.' });
    } catch (e) {
        res.json({ success: false, message: 'Gagal memperbarui profil.' });
    }
});

// ========== Change Password ==========
router.post('/profile/change-password', requireAuth, async (req, res) => {
    try {
        const bcrypt = require('bcrypt');
        const { oldPassword, newPassword, confirmPassword } = req.body;

        if (newPassword !== confirmPassword)
            return res.json({ success: false, message: 'Konfirmasi password tidak cocok.' });
        if (newPassword.length < 8)
            return res.json({ success: false, message: 'Password minimal 8 karakter.' });

        const doc = await db.collection('users').doc(req.user.uid).get();
        const user = doc.data();

        if (!user.password) return res.json({ success: false, message: 'Akun ini menggunakan login sosial.' });

        const isMatch = await bcrypt.compare(oldPassword, user.password);
        if (!isMatch) return res.json({ success: false, message: 'Password lama salah.' });

        const hashed = await bcrypt.hash(newPassword, 12);
        await db.collection('users').doc(req.user.uid).update({ password: hashed });
        logActivity('auth', 'Change password', req.user.uid);
        res.json({ success: true, message: 'Password berhasil diubah.' });
    } catch (e) {
        res.json({ success: false, message: 'Gagal mengubah password.' });
    }
});

// ========== Response Add ==========
router.post('/response/add', requireAuth, async (req, res) => {
    try {
        const { trigger, response } = req.body;
        if (!trigger || !response) return res.json({ success: false, message: 'Isi semua field.' });

        // Cek duplikat
        const snap = await db.collection('customResponses')
            .where('userId','==',req.user.uid).where('trigger','==',trigger).limit(1).get();
        if (!snap.empty) return res.json({ success: false, message: 'Trigger sudah ada.' });

        const ref = await db.collection('customResponses').add({
            userId: req.user.uid,
            trigger: trigger.toLowerCase(),
            response,
            createdAt: new Date()
        });
        logActivity('bot', `Add custom response: ${trigger}`, req.user.uid);
        res.json({ success: true, id: ref.id });
    } catch (e) {
        res.json({ success: false, message: 'Gagal menambahkan.' });
    }
});

// ========== Response Delete ==========
router.delete('/response/:id', requireAuth, async (req, res) => {
    try {
        const doc = await db.collection('customResponses').doc(req.params.id).get();
        if (!doc.exists || doc.data().userId !== req.user.uid)
            return res.json({ success: false, message: 'Tidak ditemukan.' });
        await db.collection('customResponses').doc(req.params.id).delete();
        logActivity('bot', `Delete custom response: ${req.params.id}`, req.user.uid);
        res.json({ success: true });
    } catch (e) {
        res.json({ success: false, message: 'Gagal menghapus.' });
    }
});
