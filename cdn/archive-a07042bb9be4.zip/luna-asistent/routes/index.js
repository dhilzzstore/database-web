/**
 * routes/index.js - Public Routes
 * © Kazama Dev (Dhilzz) 2026
 */

const express = require('express');
const router  = express.Router();
const { requireAuth } = require('../core/middleware');

// ========== Landing Page ==========
router.get('/', (req, res) => {
    res.render('index', {
        title: `${global.siteName} - ${global.siteTagline}`,
        membership: global.membership,
        isHome: true
    });
});

// ========== Pricing Page ==========
router.get('/pricing', (req, res) => {
    res.render('pricing', {
        title: `Harga - ${global.siteName}`,
        membership: global.membership,
        slotPrice: global.slotPrice
    });
});

// ========== Donasi ==========
router.get('/donasi', (req, res) => {
    res.render('donasi', {
        title: `Donasi - ${global.siteName}`
    });
});

// ========== Ganti Bahasa ==========
router.get('/lang/:code', (req, res) => {
    const lang = req.params.code;
    if (global.availableLangs.includes(lang)) {
        res.cookie('lang', lang, { maxAge: 365 * 24 * 60 * 60 * 1000 });
    }
    res.redirect('back');
});

module.exports = router;
