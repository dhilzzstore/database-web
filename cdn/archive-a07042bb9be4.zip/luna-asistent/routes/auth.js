/**
 * routes/auth.js - Authentication Routes
 * © Kazama Dev (Dhilzz) 2026
 */

const express    = require('express');
const router     = express.Router();
const passport   = require('passport');
const bcrypt     = require('bcrypt');
const crypto     = require('crypto');
const { db }     = require('../core/firebase');
const mailer     = require('../core/mailer');
const { logActivity } = require('../core/middleware');
const { guestOnly, verifyRecaptcha } = require('../core/middleware');

// ========== Login Page ==========
router.get('/login', guestOnly, (req, res) => {
    res.render('auth/login', {
        title: `Login - ${global.siteName}`,
        error: req.flash('error'),
        success: req.flash('success')
    });
});

// ========== Register Page ==========
router.get('/register', guestOnly, (req, res) => {
    if (!global.registrationOpen) {
        req.flash('error', 'Pendaftaran sementara ditutup.');
        return res.redirect('/auth/login');
    }
    res.render('auth/register', {
        title: `Daftar - ${global.siteName}`,
        error: req.flash('error')
    });
});

// ========== Login POST ==========
router.post('/login', guestOnly, verifyRecaptcha, (req, res, next) => {
    passport.authenticate('local', async (err, user, info) => {
        if (err) return next(err);
        if (!user) {
            req.flash('error', info?.message || 'Login gagal.');
            return res.redirect('/auth/login');
        }

        req.logIn(user, async (err) => {
            if (err) return next(err);

            // Update last login
            await db.collection('users').doc(user.uid).update({
                lastLogin: new Date(),
                loginCount: (user.loginCount || 0) + 1
            });

            logActivity('auth', `Login: ${user.email || user.username}`, user.uid);

            // Set session flag untuk welcome overlay
            req.session.showWelcome = true;

            if (user.role === 'admin') {
                return res.redirect('/admin');
            }
            return res.redirect('/dashboard');
        });
    })(req, res, next);
});

// ========== Register POST ==========
router.post('/register', guestOnly, verifyRecaptcha, async (req, res) => {
    try {
        const { name, username, email, password, confirmPassword, referral } = req.body;

        if (!global.registrationOpen) {
            req.flash('error', 'Pendaftaran sementara ditutup.');
            return res.redirect('/auth/register');
        }

        // Validasi
        if (!name || !username || !email || !password) {
            req.flash('error', 'Semua field wajib diisi.');
            return res.redirect('/auth/register');
        }

        if (password !== confirmPassword) {
            req.flash('error', 'Password tidak cocok.');
            return res.redirect('/auth/register');
        }

        if (password.length < 8) {
            req.flash('error', 'Password minimal 8 karakter.');
            return res.redirect('/auth/register');
        }

        // Cek email
        const emailSnap = await db.collection('users')
            .where('email', '==', email.toLowerCase()).limit(1).get();
        if (!emailSnap.empty) {
            req.flash('error', 'Email sudah digunakan.');
            return res.redirect('/auth/register');
        }

        // Cek username
        const usernameSnap = await db.collection('users')
            .where('username', '==', username.toLowerCase()).limit(1).get();
        if (!usernameSnap.empty) {
            req.flash('error', 'Username sudah digunakan.');
            return res.redirect('/auth/register');
        }

        // Hash password
        const hashed = await bcrypt.hash(password, 12);

        // Trial expiry
        const trialExpiry = new Date();
        trialExpiry.setDate(trialExpiry.getDate() + global.trialDays);

        // Handle referral
        let referredBy = null;
        if (referral) {
            const refSnap = await db.collection('users')
                .where('referralCode', '==', referral.toUpperCase()).limit(1).get();
            if (!refSnap.empty) {
                referredBy = refSnap.docs[0].id;
                // Tambah 1 hari ke referrer
                const refUser = refSnap.docs[0].data();
                const refExpiry = refUser.membershipExpiry
                    ? new Date(refUser.membershipExpiry.toDate ? refUser.membershipExpiry.toDate() : refUser.membershipExpiry)
                    : new Date();
                refExpiry.setDate(refExpiry.getDate() + global.referralBonusDays);
                await db.collection('users').doc(refSnap.docs[0].id).update({
                    membershipExpiry: refExpiry,
                    referralCount: (refUser.referralCount || 0) + 1
                });
            }
        }

        const newUser = {
            name,
            username: username.toLowerCase(),
            email: email.toLowerCase(),
            password: hashed,
            role: 'user',
            slots: global.defaultSlots,
            membershipExpiry: trialExpiry,
            membershipPlan: 'trial',
            trialUsed: true,
            referralCode: generateReferralCode(),
            referredBy,
            referralCount: 0,
            banned: false,
            createdAt: new Date(),
            lastLogin: new Date()
        };

        const ref = await db.collection('users').add(newUser);

        // Kirim welcome email
        try { await mailer.sendWelcome(email, name); } catch (e) {}

        logActivity('auth', `Register: ${email}`, ref.id);

        req.flash('success', `Akun berhasil dibuat! Anda mendapat ${global.trialDays} hari trial gratis.`);
        res.redirect('/auth/login');

    } catch (e) {
        console.error('Register error:', e);
        req.flash('error', 'Terjadi kesalahan. Coba lagi.');
        res.redirect('/auth/register');
    }
});

// ========== Forgot Password ==========
router.get('/forgot-password', guestOnly, (req, res) => {
    res.render('auth/forgot-password', {
        title: `Lupa Password - ${global.siteName}`,
        error: req.flash('error'),
        success: req.flash('success')
    });
});

router.post('/forgot-password', guestOnly, async (req, res) => {
    const { email } = req.body;
    try {
        const snap = await db.collection('users')
            .where('email', '==', email.toLowerCase()).limit(1).get();

        // Selalu kirim pesan sukses (security: jangan reveal apakah email ada)
        req.flash('success', 'Jika email terdaftar, link reset akan dikirim.');
        res.redirect('/auth/forgot-password');

        if (snap.empty) return;

        const user = { uid: snap.docs[0].id, ...snap.docs[0].data() };
        const token = crypto.randomBytes(32).toString('hex');
        const expires = new Date(Date.now() + 3600000); // 1 jam

        await db.collection('resetTokens').doc(token).set({
            uid: user.uid,
            email: user.email,
            expires
        });

        const link = `${global.baseUrl}/auth/reset-password/${token}`;
        await mailer.sendResetPassword(user.email, user.name, link);
        logActivity('auth', `Forgot password: ${email}`, user.uid);

    } catch (e) {
        console.error('Forgot password error:', e);
    }
});

// ========== Reset Password ==========
router.get('/reset-password/:token', guestOnly, async (req, res) => {
    try {
        const tokenDoc = await db.collection('resetTokens').doc(req.params.token).get();

        if (!tokenDoc.exists || new Date(tokenDoc.data().expires.toDate ? tokenDoc.data().expires.toDate() : tokenDoc.data().expires) < new Date()) {
            req.flash('error', 'Link reset tidak valid atau sudah kadaluarsa.');
            return res.redirect('/auth/forgot-password');
        }

        res.render('auth/reset-password', {
            title: `Reset Password - ${global.siteName}`,
            token: req.params.token,
            error: req.flash('error')
        });
    } catch (e) {
        res.redirect('/auth/forgot-password');
    }
});

router.post('/reset-password/:token', guestOnly, async (req, res) => {
    const { password, confirmPassword } = req.body;
    try {
        const tokenDoc = await db.collection('resetTokens').doc(req.params.token).get();

        if (!tokenDoc.exists || new Date(tokenDoc.data().expires.toDate ? tokenDoc.data().expires.toDate() : tokenDoc.data().expires) < new Date()) {
            req.flash('error', 'Link reset tidak valid atau sudah kadaluarsa.');
            return res.redirect('/auth/forgot-password');
        }

        if (password !== confirmPassword) {
            req.flash('error', 'Password tidak cocok.');
            return res.redirect(`/auth/reset-password/${req.params.token}`);
        }

        if (password.length < 8) {
            req.flash('error', 'Password minimal 8 karakter.');
            return res.redirect(`/auth/reset-password/${req.params.token}`);
        }

        const hashed = await bcrypt.hash(password, 12);
        await db.collection('users').doc(tokenDoc.data().uid).update({ password: hashed });
        await db.collection('resetTokens').doc(req.params.token).delete();

        logActivity('auth', `Reset password: ${tokenDoc.data().email}`, tokenDoc.data().uid);
        req.flash('success', 'Password berhasil diubah. Silakan login.');
        res.redirect('/auth/login');

    } catch (e) {
        req.flash('error', 'Terjadi kesalahan.');
        res.redirect('/auth/forgot-password');
    }
});

// ========== Google OAuth ==========
router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
router.get('/google/callback',
    passport.authenticate('google', { failureRedirect: '/auth/login', failureFlash: true }),
    (req, res) => {
        req.session.showWelcome = true;
        res.redirect(req.user?.role === 'admin' ? '/admin' : '/dashboard');
    }
);

// ========== GitHub OAuth ==========
router.get('/github', passport.authenticate('github', { scope: ['user:email'] }));
router.get('/github/callback',
    passport.authenticate('github', { failureRedirect: '/auth/login', failureFlash: true }),
    (req, res) => {
        req.session.showWelcome = true;
        res.redirect(req.user?.role === 'admin' ? '/admin' : '/dashboard');
    }
);

// ========== Logout ==========
router.get('/logout', (req, res) => {
    const uid = req.user?.uid;
    req.logout((err) => {
        if (err) console.error(err);
        req.session.destroy();
        res.clearCookie('connect.sid');
        logActivity('auth', 'Logout', uid);
        res.redirect('/');
    });
});

function generateReferralCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = router;
