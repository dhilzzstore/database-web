/**
 * routes/payment.js - Payment Routes (Pakasir SDK)
 * © Kazama Dev (Dhilzz) 2026
 */

const express  = require('express');
const router   = express.Router();
const axios    = require('axios');
const { db }   = require('../core/firebase');
const mailer   = require('../core/mailer');
const { requireAuth, logActivity } = require('../core/middleware');
const crypto   = require('crypto');

// ========== Payment Detail Page ==========
// Akses: /payment/detail?orderId=&paket=
router.get('/detail', requireAuth, async (req, res) => {
    try {
        const { orderId, paket } = req.query;

        if (!paket) {
            return res.redirect('/dashboard/pricing');
        }

        const user = req.user;
        const plan = global.membership[paket];

        if (!plan && paket !== 'slot') {
            return res.redirect('/dashboard/pricing');
        }

        // Hitung harga
        let amount = paket === 'slot' ? global.slotPrice : plan.price;
        let discount = 0;
        let voucherApplied = null;

        // Cek voucher dari session
        if (req.session.voucher) {
            const v = global.vouchers.find(v =>
                v.code === req.session.voucher && v.active && v.used < v.maxUse
            );
            if (v) {
                if (v.type === 'percent') {
                    discount = Math.floor(amount * v.discount / 100);
                } else {
                    discount = v.discount;
                }
                voucherApplied = v;
            }
        }

        const finalAmount = Math.max(0, amount - discount);

        // Buat order ID jika belum ada
        const oid = orderId || `LUNA-${Date.now()}-${user.uid.substring(0, 6).toUpperCase()}`;

        // Simpan order sementara
        await db.collection('orders').doc(oid).set({
            orderId: oid,
            userId: user.uid,
            userName: user.name,
            userEmail: user.email,
            plan: paket,
            planName: paket === 'slot' ? 'Tambah Slot' : plan.name,
            originalAmount: amount,
            discount,
            finalAmount,
            voucherCode: voucherApplied?.code || null,
            status: 'pending',
            createdAt: new Date()
        }, { merge: true });

        res.render('payment/detail', {
            title: `Pembayaran - ${global.siteName}`,
            user,
            orderId: oid,
            plan: paket,
            planData: paket === 'slot' ? { name: 'Tambah Slot', features: ['1 slot tambahan'] } : plan,
            amount,
            discount,
            finalAmount,
            vouchers: global.vouchers.filter(v => v.active),
            voucherApplied
        });
    } catch (e) {
        console.error('Payment detail error:', e);
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Apply Voucher ==========
router.post('/voucher', requireAuth, (req, res) => {
    const { code, amount } = req.body;
    const v = global.vouchers.find(v =>
        v.code === code.toUpperCase() && v.active && v.used < v.maxUse
    );

    if (!v) {
        return res.json({ success: false, message: 'Voucher tidak valid atau sudah habis.' });
    }

    let discount = 0;
    if (v.type === 'percent') {
        discount = Math.floor(parseFloat(amount) * v.discount / 100);
    } else {
        discount = v.discount;
    }

    req.session.voucher = v.code;
    res.json({
        success: true,
        discount,
        finalAmount: Math.max(0, parseFloat(amount) - discount),
        message: `Voucher ${v.code} berhasil diterapkan! Diskon: Rp${discount.toLocaleString('id-ID')}`
    });
});

// ========== Create Payment (Pakasir) ==========
router.post('/create', requireAuth, async (req, res) => {
    try {
        const { orderId, paket } = req.body;
        const user = req.user;

        const orderDoc = await db.collection('orders').doc(orderId).get();
        if (!orderDoc.exists || orderDoc.data().userId !== user.uid) {
            return res.json({ success: false, message: 'Order tidak ditemukan.' });
        }

        const order = orderDoc.data();

        // Pakasir API
        const pakasirResponse = await axios.post(
            `https://api.pakasir.com/v1/payment/create`,
            {
                project: global.pakasirProject,
                order_id: orderId,
                amount: order.finalAmount,
                customer_name: user.name,
                customer_email: user.email,
                description: `${global.siteName} - ${order.planName}`,
                callback_url: `${global.baseUrl}/payment/callback`,
                return_url: `${global.baseUrl}/payment/success?orderId=${orderId}`
            },
            {
                headers: {
                    'Authorization': `Bearer ${global.pakasirApikey}`,
                    'Content-Type': 'application/json'
                }
            }
        ).catch(e => {
            // Fallback jika Pakasir API tidak tersedia (development)
            return {
                data: {
                    success: true,
                    payment_url: `/payment/mock?orderId=${orderId}`,
                    transaction_id: `TXN-${Date.now()}`
                }
            };
        });

        if (pakasirResponse.data.success || pakasirResponse.data.payment_url) {
            await db.collection('orders').doc(orderId).update({
                paymentUrl: pakasirResponse.data.payment_url,
                transactionId: pakasirResponse.data.transaction_id || null,
                updatedAt: new Date()
            });

            logActivity('payment', `Create payment: ${orderId}`, user.uid);
            res.json({
                success: true,
                paymentUrl: pakasirResponse.data.payment_url
            });
        } else {
            res.json({ success: false, message: 'Gagal membuat pembayaran.' });
        }
    } catch (e) {
        console.error('Create payment error:', e);
        res.json({ success: false, message: 'Terjadi kesalahan.' });
    }
});

// ========== Payment Callback (Webhook) ==========
router.post('/callback', async (req, res) => {
    try {
        const { order_id, status, signature, amount } = req.body;

        // Verifikasi signature
        const expectedSig = crypto
            .createHmac('sha256', global.pakasirApikey)
            .update(`${order_id}${amount}${status}`)
            .digest('hex');

        if (signature && signature !== expectedSig) {
            return res.status(400).json({ success: false, message: 'Invalid signature' });
        }

        if (status === 'success' || status === 'paid') {
            await processSuccessPayment(order_id);
        } else if (status === 'failed' || status === 'expired') {
            await db.collection('orders').doc(order_id).update({
                status,
                updatedAt: new Date()
            });
        }

        res.json({ success: true });
    } catch (e) {
        console.error('Callback error:', e);
        res.status(500).json({ success: false });
    }
});

// ========== Payment Success Page ==========
router.get('/success', requireAuth, async (req, res) => {
    try {
        const { orderId } = req.query;
        const orderDoc = await db.collection('orders').doc(orderId).get();

        if (!orderDoc.exists) {
            return res.redirect('/dashboard');
        }

        // Proses jika belum diproses
        if (orderDoc.data().status !== 'success') {
            await processSuccessPayment(orderId);
        }

        const order = { id: orderDoc.id, ...orderDoc.data() };
        delete req.session.voucher;

        res.render('payment/success', {
            title: `Pembayaran Berhasil - ${global.siteName}`,
            user: req.user,
            order
        });
    } catch (e) {
        res.redirect('/dashboard');
    }
});

// ========== Mock Payment (Development) ==========
router.get('/mock', requireAuth, async (req, res) => {
    const { orderId } = req.query;
    res.render('payment/mock', {
        title: `Simulasi Pembayaran - ${global.siteName}`,
        user: req.user,
        orderId
    });
});

router.post('/mock/confirm', requireAuth, async (req, res) => {
    const { orderId } = req.body;
    await processSuccessPayment(orderId);
    res.redirect(`/payment/success?orderId=${orderId}`);
});

// ========== Helper: Proses Sukses ==========
async function processSuccessPayment(orderId) {
    const orderDoc = await db.collection('orders').doc(orderId).get();
    if (!orderDoc.exists) return;

    const order = orderDoc.data();
    if (order.status === 'success') return; // Sudah diproses

    const userDoc = await db.collection('users').doc(order.userId).get();
    if (!userDoc.exists) return;

    const user = userDoc.data();
    const now = new Date();

    // Update expiry
    const currentExpiry = user.membershipExpiry
        ? new Date(user.membershipExpiry.toDate ? user.membershipExpiry.toDate() : user.membershipExpiry)
        : now;
    const base = currentExpiry > now ? currentExpiry : now;

    let newExpiry = new Date(base);
    let updateData = { membershipPlan: order.plan };

    if (order.plan === 'slot') {
        // Tambah slot
        updateData = { slots: (user.slots || global.defaultSlots) + 1 };
    } else if (order.plan === '7day') {
        newExpiry.setDate(newExpiry.getDate() + 7);
        updateData.membershipExpiry = newExpiry;
    } else if (order.plan === '1month') {
        newExpiry.setDate(newExpiry.getDate() + 30);
        updateData.membershipExpiry = newExpiry;
    } else if (order.plan === '1year') {
        newExpiry.setFullYear(newExpiry.getFullYear() + 1);
        updateData.membershipExpiry = newExpiry;
    }

    await db.collection('users').doc(order.userId).update(updateData);

    // Update order status
    await db.collection('orders').doc(orderId).update({
        status: 'success',
        processedAt: new Date()
    });

    // Catat payment
    await db.collection('payments').add({
        orderId,
        userId: order.userId,
        userName: order.userName,
        userEmail: order.userEmail,
        plan: order.plan,
        amount: order.finalAmount,
        status: 'success',
        createdAt: new Date()
    });

    // Update pemakaian voucher
    if (order.voucherCode) {
        const cfg = require('../data/config.json');
        const idx = cfg.vouchers.findIndex(v => v.code === order.voucherCode);
        if (idx !== -1) {
            cfg.vouchers[idx].used++;
            global.saveConfig({ vouchers: cfg.vouchers });
        }
    }

    // Kirim email konfirmasi
    try {
        await mailer.sendPaymentConfirm(
            order.userEmail, order.userName,
            order.planName, updateData.membershipExpiry
        );
    } catch (e) {}

    logActivity('payment', `Payment success: ${orderId}`, order.userId);
}

module.exports = router;
