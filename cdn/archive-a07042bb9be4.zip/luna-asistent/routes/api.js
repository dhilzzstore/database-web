/**
 * routes/api.js - API Routes untuk Bot Manager
 * © Kazama Dev (Dhilzz) 2026
 */

const express = require('express');
const router  = express.Router();
const { db }  = require('../core/firebase');
const { requireAuth, requireAdmin, logActivity } = require('../core/middleware');
const botManager = require('../core/botManager');

// ========== Bot Start (Pairing) ==========
router.post('/bot/start', requireAuth, async (req, res) => {
    try {
        const { connectionId, phone } = req.body;
        const user = req.user;

        // Cek kepemilikan
        const doc = await db.collection('connections').doc(connectionId).get();
        if (!doc.exists || doc.data().userId !== user.uid)
            return res.json({ success: false, message: 'Koneksi tidak ditemukan.' });

        // Cek membership aktif
        const now = new Date();
        const exp = user.membershipExpiry
            ? new Date(user.membershipExpiry.toDate ? user.membershipExpiry.toDate() : user.membershipExpiry)
            : null;
        if (!exp || exp < now)
            return res.json({ success: false, message: 'Membership tidak aktif. Silakan upgrade.' });

        // Ambil config bot user
        const cfgSnap = await db.collection('botConfigs')
            .where('userId', '==', user.uid).limit(1).get();
        const botCfg = cfgSnap.empty ? { ...global.botConfig } : cfgSnap.docs[0].data();

        // Update nomor di DB
        await db.collection('connections').doc(connectionId).update({
            phoneNumber: phone,
            status: 'waiting',
            updatedAt: new Date()
        });

        const result = await botManager.startBot(connectionId, phone, botCfg, user);

        logActivity('bot', `Start bot slot: ${doc.data().slotNumber}, phone: ${phone}`, user.uid);
        res.json({ success: true, pairingCode: result.pairingCode });
    } catch (e) {
        console.error('Bot start error:', e);
        res.json({ success: false, message: e.message || 'Gagal memulai bot.' });
    }
});

// ========== Bot Stop ==========
router.post('/bot/stop', requireAuth, async (req, res) => {
    try {
        const { connectionId } = req.body;
        const doc = await db.collection('connections').doc(connectionId).get();
        if (!doc.exists || doc.data().userId !== req.user.uid)
            return res.json({ success: false, message: 'Koneksi tidak ditemukan.' });

        await botManager.stopBot(connectionId);
        await db.collection('connections').doc(connectionId).update({ status: 'inactive', lastActive: new Date() });

        logActivity('bot', `Stop bot: ${connectionId}`, req.user.uid);
        res.json({ success: true, message: 'Bot berhasil dihentikan.' });
    } catch (e) {
        res.json({ success: false, message: e.message || 'Gagal menghentikan bot.' });
    }
});

// ========== Bot Reset Session ==========
router.post('/bot/reset', requireAuth, async (req, res) => {
    try {
        const { connectionId } = req.body;
        const doc = await db.collection('connections').doc(connectionId).get();
        if (!doc.exists || doc.data().userId !== req.user.uid)
            return res.json({ success: false, message: 'Koneksi tidak ditemukan.' });

        await botManager.resetSession(connectionId);
        await db.collection('connections').doc(connectionId).update({
            status: 'inactive', phoneNumber: null, updatedAt: new Date()
        });

        logActivity('bot', `Reset session: ${connectionId}`, req.user.uid);
        res.json({ success: true, message: 'Session berhasil di-reset.' });
    } catch (e) {
        res.json({ success: false, message: e.message || 'Gagal reset session.' });
    }
});

// ========== Bot Status ==========
router.get('/bot/status', requireAuth, async (req, res) => {
    try {
        const { connectionId } = req.query;
        const doc = await db.collection('connections').doc(connectionId).get();
        if (!doc.exists || doc.data().userId !== req.user.uid)
            return res.json({ success: false, status: 'unknown' });

        const liveStatus = botManager.getBotStatus(connectionId);
        const dbData = doc.data();

        res.json({
            success: true,
            status: liveStatus.status || dbData.status,
            pairingCode: liveStatus.pairingCode || null,
            phoneNumber: dbData.phoneNumber,
            lastActive: dbData.lastActive
        });
    } catch (e) {
        res.json({ success: false, status: 'error' });
    }
});

// ========== Get Pairing Code ==========
router.post('/bot/pairing-code', requireAuth, async (req, res) => {
    try {
        const { connectionId } = req.body;
        const doc = await db.collection('connections').doc(connectionId).get();
        if (!doc.exists || doc.data().userId !== req.user.uid)
            return res.json({ success: false, message: 'Koneksi tidak ditemukan.' });

        const code = await botManager.requestPairingCode(connectionId);
        res.json({ success: true, pairingCode: code });
    } catch (e) {
        res.json({ success: false, message: e.message || 'Gagal mendapatkan kode.' });
    }
});

// ========== Bot Config Update (API) ==========
router.post('/bot/config', requireAuth, async (req, res) => {
    try {
        const { connectionId, config } = req.body;
        const doc = await db.collection('connections').doc(connectionId).get();
        if (!doc.exists || doc.data().userId !== req.user.uid)
            return res.json({ success: false, message: 'Koneksi tidak ditemukan.' });

        await botManager.updateConfig(connectionId, config);
        res.json({ success: true, message: 'Config diperbarui.' });
    } catch (e) {
        res.json({ success: false, message: e.message });
    }
});

// ========== Admin: Stats ==========
router.get('/admin/stats', requireAdmin, async (req, res) => {
    try {
        const usersSnap = await db.collection('users').get();
        const paySnap   = await db.collection('payments').where('status','==','success').get();
        res.json({
            success: true,
            totalUsers: usersSnap.size,
            totalRevenue: paySnap.docs.reduce((s,d) => s + (d.data().amount||0), 0),
            activeBots: botManager.getActiveBotCount()
        });
    } catch (e) {
        res.json({ success: false });
    }
});

// ========== Admin: Extend User ==========
router.post('/admin/extend', requireAdmin, async (req, res) => {
    try {
        const { uid, days } = req.body;
        const userDoc = await db.collection('users').doc(uid).get();
        if (!userDoc.exists) return res.json({ success: false, message: 'User tidak ditemukan.' });

        const userData = userDoc.data();
        const now = new Date();
        const current = userData.membershipExpiry
            ? new Date(userData.membershipExpiry.toDate ? userData.membershipExpiry.toDate() : userData.membershipExpiry)
            : now;
        const base = current > now ? current : now;
        base.setDate(base.getDate() + parseInt(days));

        await db.collection('users').doc(uid).update({ membershipExpiry: base });
        logActivity('admin', `Extend user ${uid} +${days} hari`, req.user.uid);
        res.json({ success: true, newExpiry: base });
    } catch (e) {
        res.json({ success: false, message: e.message });
    }
});

// ========== Voucher Check ==========
router.post('/voucher/check', requireAuth, (req, res) => {
    const { code } = req.body;
    const v = global.vouchers?.find(v => v.code === code?.toUpperCase() && v.active && v.used < v.maxUse);
    if (!v) return res.json({ success: false, message: 'Voucher tidak valid atau habis.' });
    res.json({ success: true, voucher: { code: v.code, discount: v.discount, type: v.type } });
});

// ========== Feedback Submit ==========
router.post('/feedback', requireAuth, async (req, res) => {
    try {
        const { type, subject, message } = req.body;
        if (!subject || !message) return res.json({ success: false, message: 'Isi semua field.' });
        await db.collection('feedbacks').add({
            userId: req.user.uid,
            userName: req.user.name,
            userEmail: req.user.email,
            type: type || 'feedback',
            subject, message,
            status: 'unread',
            createdAt: new Date()
        });
        logActivity('feedback', `Feedback: ${subject}`, req.user.uid);
        res.json({ success: true, message: 'Feedback terkirim!' });
    } catch (e) {
        res.json({ success: false, message: 'Gagal mengirim.' });
    }
});

module.exports = router;
