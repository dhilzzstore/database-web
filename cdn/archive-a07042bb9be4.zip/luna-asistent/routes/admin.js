/**
 * routes/admin.js - Admin Dashboard Routes
 * © Kazama Dev (Dhilzz) 2026
 */

const express  = require('express');
const router   = express.Router();
const { db }   = require('../core/firebase');
const { requireAdmin, logActivity } = require('../core/middleware');
const path     = require('path');
const fs       = require('fs');

router.use(requireAdmin);

// ========== Admin Dashboard ==========
router.get('/', async (req, res) => {
    try {
        // Stats
        const usersSnap    = await db.collection('users').get();
        const paySnap      = await db.collection('payments').where('status', '==', 'success').get();
        const feedbackSnap = await db.collection('feedbacks').where('status', '==', 'unread').get();

        const totalUsers    = usersSnap.size;
        const activeMembers = usersSnap.docs.filter(d => {
            const exp = d.data().membershipExpiry;
            return exp && new Date(exp.toDate ? exp.toDate() : exp) > new Date();
        }).length;

        const totalRevenue = paySnap.docs.reduce((sum, d) => sum + (d.data().amount || 0), 0);
        const unreadFeedbacks = feedbackSnap.size;

        // Recent users
        const recentUsers = usersSnap.docs
            .sort((a, b) => {
                const da = a.data().createdAt?.toDate ? a.data().createdAt.toDate() : new Date(a.data().createdAt || 0);
                const db2 = b.data().createdAt?.toDate ? b.data().createdAt.toDate() : new Date(b.data().createdAt || 0);
                return db2 - da;
            })
            .slice(0, 5)
            .map(d => ({ uid: d.id, ...d.data() }));

        // Revenue chart (7 hari terakhir)
        const revenueChart = buildRevenueChart(paySnap.docs);

        res.render('admin/index', {
            title: `Admin Dashboard - ${global.siteName}`,
            user: req.user,
            stats: { totalUsers, activeMembers, totalRevenue, unreadFeedbacks },
            recentUsers,
            revenueChart,
            page: 'dashboard'
        });
    } catch (e) {
        console.error(e);
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Manajemen User ==========
router.get('/users', async (req, res) => {
    try {
        const { search, status, page: pg } = req.query;
        const currentPage = parseInt(pg) || 1;
        const perPage = 20;

        let query = db.collection('users').orderBy('createdAt', 'desc');
        const snap = await query.get();
        let users = snap.docs.map(d => ({ uid: d.id, ...d.data() }));

        if (search) {
            const q = search.toLowerCase();
            users = users.filter(u =>
                u.email?.toLowerCase().includes(q) ||
                u.username?.toLowerCase().includes(q) ||
                u.name?.toLowerCase().includes(q)
            );
        }

        if (status === 'active') {
            users = users.filter(u => {
                const exp = u.membershipExpiry;
                return exp && new Date(exp.toDate ? exp.toDate() : exp) > new Date();
            });
        } else if (status === 'expired') {
            users = users.filter(u => {
                const exp = u.membershipExpiry;
                return !exp || new Date(exp.toDate ? exp.toDate() : exp) <= new Date();
            });
        } else if (status === 'banned') {
            users = users.filter(u => u.banned);
        }

        const total = users.length;
        const paginated = users.slice((currentPage - 1) * perPage, currentPage * perPage);

        res.render('admin/users', {
            title: `Manajemen User - ${global.siteName}`,
            user: req.user,
            users: paginated,
            pagination: { current: currentPage, total: Math.ceil(total / perPage), totalItems: total },
            search, status,
            page: 'users'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Tambah Waktu User ==========
router.post('/users/:uid/extend', async (req, res) => {
    try {
        const { days } = req.body;
        const userDoc = await db.collection('users').doc(req.params.uid).get();
        if (!userDoc.exists) return res.json({ success: false, message: 'User tidak ditemukan.' });

        const userData = userDoc.data();
        const now = new Date();
        const currentExpiry = userData.membershipExpiry
            ? new Date(userData.membershipExpiry.toDate ? userData.membershipExpiry.toDate() : userData.membershipExpiry)
            : now;

        const base = currentExpiry > now ? currentExpiry : now;
        base.setDate(base.getDate() + parseInt(days));

        await db.collection('users').doc(req.params.uid).update({ membershipExpiry: base });
        logActivity('admin', `Extend user ${req.params.uid} by ${days} days`, req.user.uid);

        res.json({ success: true, message: `Berhasil tambah ${days} hari.`, newExpiry: base });
    } catch (e) {
        res.json({ success: false, message: 'Gagal.' });
    }
});

// ========== Ban/Unban User ==========
router.post('/users/:uid/ban', async (req, res) => {
    try {
        const userDoc = await db.collection('users').doc(req.params.uid).get();
        if (!userDoc.exists) return res.json({ success: false, message: 'User tidak ditemukan.' });

        const isBanned = userDoc.data().banned;
        await db.collection('users').doc(req.params.uid).update({ banned: !isBanned });

        logActivity('admin', `${isBanned ? 'Unban' : 'Ban'} user ${req.params.uid}`, req.user.uid);
        res.json({ success: true, banned: !isBanned });
    } catch (e) {
        res.json({ success: false, message: 'Gagal.' });
    }
});

// ========== Hapus User ==========
router.delete('/users/:uid', async (req, res) => {
    try {
        await db.collection('users').doc(req.params.uid).delete();
        logActivity('admin', `Delete user ${req.params.uid}`, req.user.uid);
        res.json({ success: true });
    } catch (e) {
        res.json({ success: false, message: 'Gagal.' });
    }
});

// ========== Payments ==========
router.get('/payments', async (req, res) => {
    try {
        const snap = await db.collection('payments').orderBy('createdAt', 'desc').limit(100).get();
        const payments = snap.docs.map(d => ({ id: d.id, ...d.data() }));

        const totalRevenue = payments.filter(p => p.status === 'success')
            .reduce((sum, p) => sum + (p.amount || 0), 0);

        res.render('admin/payments', {
            title: `Pembayaran - ${global.siteName}`,
            user: req.user,
            payments,
            totalRevenue,
            page: 'payments'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Monitoring Pendapatan ==========
router.get('/revenue', async (req, res) => {
    try {
        const snap = await db.collection('payments').where('status', '==', 'success').get();
        const payments = snap.docs.map(d => ({ id: d.id, ...d.data() }));

        const revenueByPlan = {
            '7day': 0, '1month': 0, '1year': 0, 'slot': 0
        };

        payments.forEach(p => {
            if (revenueByPlan.hasOwnProperty(p.plan)) {
                revenueByPlan[p.plan] += p.amount || 0;
            }
        });

        const daily = buildRevenueChart(snap.docs);
        const monthly = buildMonthlyChart(snap.docs);

        res.render('admin/revenue', {
            title: `Monitoring Pendapatan - ${global.siteName}`,
            user: req.user,
            revenueByPlan,
            daily,
            monthly,
            totalRevenue: payments.reduce((s, p) => s + (p.amount || 0), 0),
            totalTransactions: payments.length,
            page: 'revenue'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Feedback / Report ==========
router.get('/feedbacks', async (req, res) => {
    try {
        const snap = await db.collection('feedbacks').orderBy('createdAt', 'desc').get();
        const feedbacks = snap.docs.map(d => ({ id: d.id, ...d.data() }));

        res.render('admin/feedbacks', {
            title: `Feedback & Report - ${global.siteName}`,
            user: req.user,
            feedbacks,
            page: 'feedbacks'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

router.post('/feedbacks/:id/read', async (req, res) => {
    try {
        await db.collection('feedbacks').doc(req.params.id).update({ status: 'read' });
        res.json({ success: true });
    } catch (e) {
        res.json({ success: false });
    }
});

// ========== Voucher ==========
router.get('/vouchers', (req, res) => {
    res.render('admin/vouchers', {
        title: `Voucher - ${global.siteName}`,
        user: req.user,
        vouchers: global.vouchers,
        page: 'vouchers'
    });
});

router.post('/vouchers', (req, res) => {
    try {
        const { code, discount, type, maxUse } = req.body;
        const newVoucher = {
            code: code.toUpperCase(),
            discount: parseFloat(discount),
            type,
            maxUse: parseInt(maxUse),
            used: 0,
            active: true
        };

        const current = require('../data/config.json');
        current.vouchers = current.vouchers || [];

        // Cek duplikat
        if (current.vouchers.some(v => v.code === newVoucher.code)) {
            return res.json({ success: false, message: 'Kode voucher sudah ada.' });
        }

        current.vouchers.push(newVoucher);
        global.saveConfig({ vouchers: current.vouchers });
        logActivity('admin', `Add voucher: ${code}`, req.user.uid);

        res.json({ success: true });
    } catch (e) {
        res.json({ success: false, message: 'Gagal.' });
    }
});

router.post('/vouchers/:code/toggle', (req, res) => {
    try {
        const current = require('../data/config.json');
        const idx = current.vouchers.findIndex(v => v.code === req.params.code);
        if (idx === -1) return res.json({ success: false });
        current.vouchers[idx].active = !current.vouchers[idx].active;
        global.saveConfig({ vouchers: current.vouchers });
        res.json({ success: true, active: current.vouchers[idx].active });
    } catch (e) {
        res.json({ success: false });
    }
});

// ========== Konfigurasi Website ==========
router.get('/config', (req, res) => {
    const currentConfig = require('../data/config.json');
    res.render('admin/config', {
        title: `Konfigurasi - ${global.siteName}`,
        user: req.user,
        config: currentConfig,
        page: 'config'
    });
});

router.post('/config', (req, res) => {
    try {
        const updates = {};

        // Maintenance toggle
        if (req.body.maintenance !== undefined) {
            updates.maintenance = req.body.maintenance === 'true' || req.body.maintenance === true;
        }
        if (req.body.maintenanceMessage) updates.maintenanceMessage = req.body.maintenanceMessage;
        if (req.body.registrationOpen !== undefined) {
            updates.registrationOpen = req.body.registrationOpen === 'true';
        }

        // Membership prices
        if (req.body['membership.7day.price']) {
            updates.membership = {
                '7day': { price: parseInt(req.body['membership.7day.price']) },
                '1month': { price: parseInt(req.body['membership.1month.price']) },
                '1year': { price: parseInt(req.body['membership.1year.price']) }
            };
        }

        if (req.body.slotPrice) updates.slotPrice = parseInt(req.body.slotPrice);
        if (req.body.trialDays) updates.trialDays = parseInt(req.body.trialDays);

        // Bot config
        if (req.body.botNama) {
            updates.botConfig = {
                namaBot: req.body.botNama,
                footer: req.body.botFooter,
                welcomeMessage: req.body.botWelcome === 'on',
                autoStatus: req.body.botStatus === 'on',
                limitPerUser: parseInt(req.body.limitPerUser) || 15,
                limitPerGroup: parseInt(req.body.limitPerGroup) || 30
            };
        }

        global.saveConfig(updates);
        logActivity('admin', 'Update website config', req.user.uid);

        if (req.headers['content-type']?.includes('application/json')) {
            res.json({ success: true, message: 'Konfigurasi berhasil disimpan.' });
        } else {
            req.flash('success', 'Konfigurasi berhasil disimpan.');
            res.redirect('/admin/config');
        }
    } catch (e) {
        console.error(e);
        res.json({ success: false, message: 'Gagal.' });
    }
});

// Toggle Maintenance (Ajax)
router.post('/config/toggle-maintenance', (req, res) => {
    global.saveConfig({ maintenance: !global.maintenance });
    logActivity('admin', `Toggle maintenance: ${!global.maintenance}`, req.user.uid);
    res.json({ success: true, maintenance: global.maintenance });
});

// ========== Logs ==========
router.get('/logs', (req, res) => {
    try {
        const logDir = path.join(__dirname, '..', 'data', 'logs');
        const types = ['auth', 'bot', 'payment', 'admin', 'email', 'feedback'];
        const logs = {};

        for (const type of types) {
            const file = path.join(logDir, `${type}.log`);
            if (fs.existsSync(file)) {
                logs[type] = fs.readFileSync(file, 'utf8')
                    .split('\n')
                    .filter(Boolean)
                    .map(l => { try { return JSON.parse(l); } catch { return null; } })
                    .filter(Boolean)
                    .reverse()
                    .slice(0, 100);
            } else {
                logs[type] = [];
            }
        }

        res.render('admin/logs', {
            title: `System Logs - ${global.siteName}`,
            user: req.user,
            logs,
            page: 'logs'
        });
    } catch (e) {
        res.render('errors/500', { title: 'Error' });
    }
});

// ========== Broadcast Admin ==========
router.get('/broadcast', (req, res) => {
    res.render('admin/broadcast', {
        title: `Broadcast - ${global.siteName}`,
        user: req.user,
        page: 'broadcast'
    });
});

// ========== Helpers ==========
function buildRevenueChart(docs) {
    const days = 7;
    const result = [];
    for (let i = days - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const label = d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' });
        const total = docs
            .filter(doc => {
                const t = doc.data().createdAt?.toDate ? doc.data().createdAt.toDate() : new Date(doc.data().createdAt || 0);
                return t.toDateString() === d.toDateString() && doc.data().status === 'success';
            })
            .reduce((sum, doc) => sum + (doc.data().amount || 0), 0);
        result.push({ label, total });
    }
    return result;
}

function buildMonthlyChart(docs) {
    const months = 6;
    const result = [];
    for (let i = months - 1; i >= 0; i--) {
        const d = new Date();
        d.setMonth(d.getMonth() - i);
        const label = d.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
        const total = docs
            .filter(doc => {
                const t = doc.data().createdAt?.toDate ? doc.data().createdAt.toDate() : new Date(doc.data().createdAt || 0);
                return t.getMonth() === d.getMonth() && t.getFullYear() === d.getFullYear() && doc.data().status === 'success';
            })
            .reduce((sum, doc) => sum + (doc.data().amount || 0), 0);
        result.push({ label, total });
    }
    return result;
}

module.exports = router;
