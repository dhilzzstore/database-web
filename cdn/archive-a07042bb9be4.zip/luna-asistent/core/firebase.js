/**
 * core/firebase.js - Firebase Admin SDK Init
 * © Kazama Dev (Dhilzz) 2026
 */

const admin = require('firebase-admin');

if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId: global.firebaseConfig.projectId,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n')
        }),
        databaseURL: `https://${global.firebaseConfig.projectId}-default-rtdb.firebaseio.com`
    });
}

const db = admin.firestore();
const auth = admin.auth();

module.exports = { admin, db, auth };
