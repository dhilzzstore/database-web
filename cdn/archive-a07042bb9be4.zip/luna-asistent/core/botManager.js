/**
 * core/botManager.js - WhatsApp Bot Manager
 * Menggunakan @whiskeysockets/baileys
 * © Kazama Dev (Dhilzz) 2026
 */

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    jidDecode,
    proto,
    getContentType,
    generateWAMessageFromContent,
    prepareWAMessageMedia,
} = require('@whiskeysockets/baileys');

const { Boom }   = require('@hapi/boom');
const pino       = require('pino');
const path       = require('path');
const fs         = require('fs');
const { db }     = require('./firebase');
const { logActivity } = require('./middleware');

// ========== Store ==========
const activeBots = new Map(); // connectionId -> { sock, status, pairingCode, ... }
const SESSION_DIR = path.join(__dirname, '..', 'data', 'sessions');

if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

// ========== Start Bot ==========
async function startBot(connectionId, phone, botCfg = {}, userData = {}) {
    // Stop dulu jika sudah jalan
    if (activeBots.has(connectionId)) {
        await stopBot(connectionId);
        await new Promise(r => setTimeout(r, 1500));
    }

    const sessionPath = path.join(SESSION_DIR, connectionId);
    if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        auth: state,
        connectTimeoutMs: 60000,
        browser: ['Luna Asistent', 'Chrome', '1.0.0'],
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true,
    });

    // Store bot data
    activeBots.set(connectionId, {
        sock,
        status: 'connecting',
        pairingCode: null,
        phone,
        botCfg,
        userId: userData.uid,
        retryCount: 0
    });

    // Request pairing code jika belum ada creds
    if (!state.creds?.registered) {
        await new Promise(r => setTimeout(r, 3000));
        try {
            const cleanPhone = phone.replace(/[^0-9]/g, '');
            const code = await sock.requestPairingCode(cleanPhone);
            const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
            const botData = activeBots.get(connectionId);
            if (botData) botData.pairingCode = formatted;

            // Simpan ke DB untuk polling
            await db.collection('connections').doc(connectionId).update({
                pairingCode: formatted,
                status: 'waiting',
                updatedAt: new Date()
            });

            console.log(`[🔑] Pairing Code [${connectionId}]: ${formatted}`);
        } catch (e) {
            console.error(`[✗] Pairing code error [${connectionId}]:`, e.message);
        }
    }

    // ========== Connection Update ==========
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;
        const botData = activeBots.get(connectionId);

        if (connection === 'open') {
            console.log(`[✅] Bot Connected [${connectionId}]`);
            if (botData) { botData.status = 'connected'; botData.pairingCode = null; }

            await db.collection('connections').doc(connectionId).update({
                status: 'connected',
                pairingCode: null,
                lastActive: new Date(),
                phoneNumber: phone,
                updatedAt: new Date()
            });

            logActivity('bot', `Bot connected: ${connectionId}`, userData.uid);
        }

        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            if (botData) botData.status = 'disconnected';

            await db.collection('connections').doc(connectionId).update({
                status: 'inactive', updatedAt: new Date()
            });

            const shouldReconnect = reason !== DisconnectReason.loggedOut
                && reason !== DisconnectReason.forbidden
                && reason !== DisconnectReason.badSession;

            if (shouldReconnect && botData && botData.retryCount < 5) {
                botData.retryCount = (botData.retryCount || 0) + 1;
                console.log(`[🔄] Reconnecting [${connectionId}] attempt ${botData.retryCount}...`);
                setTimeout(() => startBot(connectionId, phone, botCfg, userData), 5000 * botData.retryCount);
            } else if (reason === DisconnectReason.loggedOut) {
                console.log(`[⚠️] Bot logged out [${connectionId}]`);
                await resetSession(connectionId);
            }

            logActivity('bot', `Bot disconnected [${connectionId}]: reason ${reason}`, userData.uid);
        }
    });

    // ========== Save Credentials ==========
    sock.ev.on('creds.update', saveCreds);

    // ========== Messages ==========
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const msg of messages) {
            if (!msg.message) continue;
            await handleMessage(sock, msg, botCfg, userData, connectionId);
        }
    });

    return {
        pairingCode: activeBots.get(connectionId)?.pairingCode || null
    };
}

// ========== Handle Message ==========
async function handleMessage(sock, msg, botCfg, userData, connectionId) {
    try {
        const from    = msg.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
        const sender  = isGroup ? msg.key.participant : from;
        const pushName = msg.pushName || 'User';

        if (msg.key.fromMe) return;

        const type = getContentType(msg.message);
        const body = type === 'conversation' ? msg.message.conversation
            : msg.message?.extendedTextMessage?.text
            || msg.message?.imageMessage?.caption
            || msg.message?.videoMessage?.caption || '';

        if (!body) return;

        const prefix = '.';
        const isCmd  = body.startsWith(prefix);
        if (!isCmd) return;

        const command = body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase();
        const args    = body.trim().split(/ +/).slice(1);
        const text    = args.join(' ');

        // ========== Commands ==========
        const botName = botCfg.namaBot || 'Luna Asistent';
        const footer  = botCfg.footer  || '©Kazama-Dev';

        const reply = async (text, options = {}) => {
            await sock.sendMessage(from, { text: `${text}\n\n_${footer}_`, ...options }, { quoted: msg });
        };

        switch (command) {
            case 'start':
            case 'menu':
            case 'help':
                await reply(
                    `*🌙 ${botName}*\n` +
                    `━━━━━━━━━━━━━━━━\n` +
                    `Halo *${pushName}*! 👋\n\n` +
                    `*📋 Menu Utama:*\n` +
                    `• ${prefix}ping - Cek status bot\n` +
                    `• ${prefix}info - Info bot\n` +
                    `• ${prefix}sticker - Buat stiker\n` +
                    `• ${prefix}tts - Text to speech\n` +
                    `• ${prefix}help - Menu bantuan\n\n` +
                    `*📌 Prefix:* ${prefix}`
                );
                break;

            case 'ping':
                const start = Date.now();
                await reply(`🏓 *Pong!*\nResponse: *${Date.now() - start}ms*`);
                break;

            case 'info':
                await reply(
                    `*🌙 ${botName} Info*\n` +
                    `━━━━━━━━━━━━━━━━\n` +
                    `• Platform: Luna Asistent\n` +
                    `• Developer: Kazama Dev (Dhilzz)\n` +
                    `• Status: ✅ Online\n` +
                    `• Uptime: ${formatUptime(process.uptime())}`
                );
                break;

            case 'sticker':
            case 's':
                if (msg.message?.imageMessage || msg.message?.videoMessage) {
                    const media = await sock.downloadMediaMessage(msg);
                    await sock.sendMessage(from, {
                        sticker: media,
                        ...options
                    }, { quoted: msg });
                } else {
                    await reply('Kirim gambar/video dengan caption *.sticker*');
                }
                break;

            default:
                // Cek custom response user
                try {
                    const snap = await db.collection('customResponses')
                        .where('userId', '==', userData.uid)
                        .where('trigger', '==', command).limit(1).get();
                    if (!snap.empty) {
                        await reply(snap.docs[0].data().response);
                    }
                } catch {}
                break;
        }

        // Log pesan
        logActivity('bot', `Command [${command}] dari ${sender}`, userData.uid);

        // Analytics
        try {
            const today = new Date().toISOString().split('T')[0];
            const anaRef = db.collection('analytics').doc(`${userData.uid}_${today}`);
            const anaDoc = await anaRef.get();
            if (anaDoc.exists) {
                await anaRef.update({ messages: (anaDoc.data().messages || 0) + 1 });
            } else {
                await anaRef.set({ userId: userData.uid, date: today, messages: 1, commands: 1 });
            }
        } catch {}

    } catch (e) {
        console.error(`[✗] Handle message error [${connectionId}]:`, e.message);
    }
}

// ========== Stop Bot ==========
async function stopBot(connectionId) {
    const botData = activeBots.get(connectionId);
    if (!botData) return;
    try {
        botData.sock?.end();
        botData.sock?.ws?.close();
    } catch {}
    activeBots.delete(connectionId);
}

// ========== Reset Session ==========
async function resetSession(connectionId) {
    await stopBot(connectionId);
    const sessionPath = path.join(SESSION_DIR, connectionId);
    if (fs.existsSync(sessionPath)) {
        fs.rmSync(sessionPath, { recursive: true, force: true });
    }
    await db.collection('connections').doc(connectionId).update({
        status: 'inactive',
        phoneNumber: null,
        pairingCode: null,
        updatedAt: new Date()
    }).catch(() => {});
}

// ========== Get Status ==========
function getBotStatus(connectionId) {
    const botData = activeBots.get(connectionId);
    if (!botData) return { status: 'inactive', pairingCode: null };
    return { status: botData.status, pairingCode: botData.pairingCode };
}

// ========== Request Pairing Code ==========
async function requestPairingCode(connectionId) {
    const botData = activeBots.get(connectionId);
    if (!botData) throw new Error('Bot tidak aktif.');
    const cleanPhone = botData.phone.replace(/[^0-9]/g, '');
    const code = await botData.sock.requestPairingCode(cleanPhone);
    const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
    botData.pairingCode = formatted;
    return formatted;
}

// ========== Update Config ==========
async function updateConfig(connectionId, config) {
    const botData = activeBots.get(connectionId);
    if (botData) botData.botCfg = { ...botData.botCfg, ...config };
}

// ========== Active Bot Count ==========
function getActiveBotCount() {
    let count = 0;
    activeBots.forEach(b => { if (b.status === 'connected') count++; });
    return count;
}

// ========== Restore Sessions (Auto-restart on server start) ==========
async function restoreSessions() {
    try {
        const snap = await db.collection('connections')
            .where('status', '==', 'connected').get();
        console.log(`[🔄] Restoring ${snap.size} bot sessions...`);
        for (const doc of snap.docs) {
            const data = doc.data();
            if (data.phoneNumber) {
                const cfgSnap = await db.collection('botConfigs')
                    .where('userId', '==', data.userId).limit(1).get();
                const botCfg = cfgSnap.empty ? { ...global.botConfig } : cfgSnap.docs[0].data();
                const userDoc = await db.collection('users').doc(data.userId).get();
                if (userDoc.exists) {
                    setTimeout(() => {
                        startBot(doc.id, data.phoneNumber, botCfg, { uid: data.userId, ...userDoc.data() });
                    }, 2000);
                }
            }
        }
    } catch (e) {
        console.error('[✗] Restore sessions error:', e.message);
    }
}

// ========== Helpers ==========
function formatUptime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}j ${m}m ${s}d`;
}

module.exports = {
    startBot,
    stopBot,
    resetSession,
    getBotStatus,
    requestPairingCode,
    updateConfig,
    getActiveBotCount,
    restoreSessions
};
