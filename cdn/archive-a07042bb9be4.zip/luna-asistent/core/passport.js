/**
 * core/passport.js - Passport Strategies
 * © Kazama Dev (Dhilzz) 2026
 */

const LocalStrategy   = require('passport-local').Strategy;
const GoogleStrategy  = require('passport-google-oauth20').Strategy;
const GithubStrategy  = require('passport-github2').Strategy;
const bcrypt          = require('bcrypt');
const { db }          = require('./firebase');

module.exports = function (passport) {

    // ========== Serialize ==========
    passport.serializeUser((user, done) => {
        done(null, user.uid);
    });

    passport.deserializeUser(async (uid, done) => {
        try {
            const doc = await db.collection('users').doc(uid).get();
            if (!doc.exists) return done(null, false);
            done(null, { uid, ...doc.data() });
        } catch (e) {
            done(e, null);
        }
    });

    // ========== Local Strategy ==========
    passport.use(new LocalStrategy(
        { usernameField: 'identifier', passwordField: 'password' },
        async (identifier, password, done) => {
            try {
                // Cari by email atau username
                let userDoc = null;
                const byEmail = await db.collection('users')
                    .where('email', '==', identifier.toLowerCase()).limit(1).get();

                if (!byEmail.empty) {
                    userDoc = { uid: byEmail.docs[0].id, ...byEmail.docs[0].data() };
                } else {
                    const byUsername = await db.collection('users')
                        .where('username', '==', identifier.toLowerCase()).limit(1).get();
                    if (!byUsername.empty) {
                        userDoc = { uid: byUsername.docs[0].id, ...byUsername.docs[0].data() };
                    }
                }

                if (!userDoc) {
                    return done(null, false, { message: 'Email/username tidak ditemukan.' });
                }

                if (!userDoc.password) {
                    return done(null, false, { message: 'Akun ini menggunakan login sosial.' });
                }

                const isMatch = await bcrypt.compare(password, userDoc.password);
                if (!isMatch) {
                    return done(null, false, { message: 'Password salah.' });
                }

                if (userDoc.banned) {
                    return done(null, false, { message: 'Akun Anda telah diblokir.' });
                }

                return done(null, userDoc);
            } catch (e) {
                return done(e);
            }
        }
    ));

    // ========== Google Strategy ==========
    passport.use(new GoogleStrategy({
        clientID: global.oauthGoogle.clientId,
        clientSecret: global.oauthGoogle.clientSecret,
        callbackURL: global.oauthGoogle.callbackUrl
    }, async (accessToken, refreshToken, profile, done) => {
        try {
            await handleOAuthUser(profile, 'google', done);
        } catch (e) {
            done(e);
        }
    }));

    // ========== GitHub Strategy ==========
    passport.use(new GithubStrategy({
        clientID: global.oauthGithub.clientId,
        clientSecret: global.oauthGithub.clientSecret,
        callbackURL: global.oauthGithub.callbackUrl,
        scope: ['user:email']
    }, async (accessToken, refreshToken, profile, done) => {
        try {
            await handleOAuthUser(profile, 'github', done);
        } catch (e) {
            done(e);
        }
    }));
};

// ========== OAuth Handler ==========
async function handleOAuthUser(profile, provider, done) {
    const email = profile.emails?.[0]?.value?.toLowerCase();
    const name = profile.displayName || profile.username || 'User';
    const avatar = profile.photos?.[0]?.value || null;
    const providerId = `${provider}_${profile.id}`;

    // Cari existing user
    let snap = await db.collection('users').where('providerId', '==', providerId).limit(1).get();

    if (!snap.empty) {
        const user = { uid: snap.docs[0].id, ...snap.docs[0].data() };
        if (user.banned) return done(null, false, { message: 'Akun Anda telah diblokir.' });
        // Update last login
        await db.collection('users').doc(user.uid).update({ lastLogin: new Date() });
        return done(null, user);
    }

    // Cek email sudah ada
    if (email) {
        let byEmail = await db.collection('users').where('email', '==', email).limit(1).get();
        if (!byEmail.empty) {
            const user = { uid: byEmail.docs[0].id, ...byEmail.docs[0].data() };
            await db.collection('users').doc(user.uid).update({
                providerId,
                provider,
                avatar,
                lastLogin: new Date()
            });
            return done(null, { ...user, providerId, provider, avatar });
        }
    }

    // Buat user baru
    const trialExpiry = new Date();
    trialExpiry.setDate(trialExpiry.getDate() + global.trialDays);

    const username = generateUsername(name);
    const newUser = {
        email: email || null,
        username,
        name,
        avatar,
        provider,
        providerId,
        role: 'user',
        slots: global.defaultSlots,
        membershipExpiry: trialExpiry,
        membershipPlan: 'trial',
        trialUsed: true,
        referralCode: generateReferralCode(),
        referredBy: null,
        referralCount: 0,
        banned: false,
        createdAt: new Date(),
        lastLogin: new Date()
    };

    const ref = await db.collection('users').add(newUser);
    return done(null, { uid: ref.id, ...newUser });
}

function generateUsername(name) {
    const base = name.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 12);
    const rand = Math.floor(Math.random() * 9999);
    return `${base}${rand}`;
}

function generateReferralCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}
