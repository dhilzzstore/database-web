/**
 * core/middleware.js - Middleware utama Luna Asistent
 * © Kazama Dev (Dhilzz) 2026
 */

const axios = require('axios');

// ========== Maintenance ==========
function maintenanceMiddleware(req, res, next) {
    const exempt = [
        /^\/payment/,
        /^\/errors/,
        /^\/auth\/logout/,
        /^\/public/,
        /^\/api\/admin/,
        /^\/admin/,
        /^\/api\/lang/
    ];

    if (!global.maintenance) return next();

    const isExempt = exempt.some(p => p.test(req.path));
    if (isExempt) return next();

    // Admin boleh akses
    if (req.user?.role === 'admin') return next();

    // API response
    if (req.path.startsWith('/api/')) {
        return res.status(503).json({
            success: false,
            message: global.maintenanceMessage || 'Sedang maintenance'
        });
    }

    return res.status(503).render('errors/maintenance', {
        title: 'Maintenance',
        message: global.maintenanceMessage
    });
}

// ========== Auth Required ==========
function requireAuth(req, res, next) {
    if (req.isAuthenticated()) return next();
    req.flash('error', 'Silakan login terlebih dahulu.');
    return res.redirect('/auth/login');
}

// ========== Admin Required ==========
function requireAdmin(req, res, next) {
    if (req.isAuthenticated() && req.user?.role === 'admin') return next();
    if (!req.isAuthenticated()) {
        req.flash('error', 'Silakan login terlebih dahulu.');
        return res.redirect('/auth/login');
    }
    return res.status(403).render('errors/403', {
        title: '403 - Akses Ditolak'
    });
}

// ========== Guest Only (sudah login redirect ke dashboard) ==========
function guestOnly(req, res, next) {
    if (req.isAuthenticated()) {
        return res.redirect('/dashboard');
    }
    next();
}

// ========== Membership Active Check ==========
function requireMembership(req, res, next) {
    if (!req.isAuthenticated()) {
        req.flash('error', 'Silakan login terlebih dahulu.');
        return res.redirect('/auth/login');
    }

    const user = req.user;
    const now = new Date();
    const expiry = user.membershipExpiry ? new Date(user.membershipExpiry) : null;

    if (!expiry || expiry < now) {
        req.flash('error', 'Membership Anda telah habis. Silakan perpanjang.');
        return res.redirect('/dashboard/pricing');
    }

    next();
}

// ========== reCAPTCHA Verify ==========
async function verifyRecaptcha(req, res, next) {
    const token = req.body['g-recaptcha-response'];

    if (!token) {
        req.flash('error', 'Verifikasi reCAPTCHA gagal.');
        return res.redirect('back');
    }

    try {
        const response = await axios.post(
            `https://www.google.com/recaptcha/api/siteverify`,
            null,
            {
                params: {
                    secret: global.recaptchaSecretKey,
                    response: token
                }
            }
        );

        if (!response.data.success) {
            req.flash('error', 'Verifikasi reCAPTCHA gagal. Coba lagi.');
            return res.redirect('back');
        }

        next();
    } catch (e) {
        console.error('reCAPTCHA error:', e.message);
        next(); // Skip jika server reCAPTCHA error
    }
}

// ========== CSRF-like Token ==========
function csrfProtection(req, res, next) {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

    const token = req.body._csrf || req.headers['x-csrf-token'];
    const sessionToken = req.session.csrfToken;

    if (!token || token !== sessionToken) {
        return res.status(403).json({ success: false, message: 'Invalid CSRF token' });
    }
    next();
}

function setCsrf(req, res, next) {
    if (!req.session.csrfToken) {
        req.session.csrfToken = require('crypto').randomBytes(32).toString('hex');
    }
    res.locals.csrfToken = req.session.csrfToken;
    next();
}

// ========== Log Activity ==========
const fs = require('fs');
const path = require('path');

function logActivity(type, message, userId = null) {
    try {
        const logDir = path.join(__dirname, '..', 'data', 'logs');
        if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });

        const logEntry = {
            timestamp: new Date().toISOString(),
            type,
            message,
            userId
        };

        const logFile = path.join(logDir, `${type}.log`);
        fs.appendFileSync(logFile, JSON.stringify(logEntry) + '\n');
    } catch (e) {
        console.error('Log error:', e.message);
    }
}

module.exports = {
    maintenanceMiddleware,
    requireAuth,
    requireAdmin,
    guestOnly,
    requireMembership,
    verifyRecaptcha,
    csrfProtection,
    setCsrf,
    logActivity
};
