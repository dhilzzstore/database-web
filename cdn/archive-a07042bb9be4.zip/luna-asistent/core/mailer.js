/**
 * core/mailer.js - Email Service Luna Asistent
 * © Kazama Dev (Dhilzz) 2026
 */

const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs');

function getTransporter() {
    return nodemailer.createTransport({
        host: global.smtpConfig.host,
        port: global.smtpConfig.port,
        secure: global.smtpConfig.secure,
        auth: {
            user: global.smtpConfig.user,
            pass: global.smtpConfig.pass
        }
    });
}

// ========== Send Reset Password ==========
async function sendResetPassword(to, name, resetLink) {
    const transporter = getTransporter();
    await transporter.sendMail({
        from: global.smtpConfig.from,
        to,
        subject: `[${global.siteName}] Reset Password`,
        html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0f;color:#e0e0e0;padding:30px;border-radius:12px;border:1px solid #1a3a5c;">
            <div style="text-align:center;margin-bottom:24px;">
                <h1 style="color:#00aaff;margin:0;">🌙 ${global.siteName}</h1>
            </div>
            <h2 style="color:#fff;">Halo, ${name}!</h2>
            <p>Kami menerima permintaan reset password untuk akun Anda.</p>
            <p>Klik tombol di bawah untuk membuat password baru:</p>
            <div style="text-align:center;margin:32px 0;">
                <a href="${resetLink}" style="background:linear-gradient(135deg,#0066cc,#00aaff);color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold;font-size:16px;">Reset Password</a>
            </div>
            <p style="color:#999;font-size:13px;">Link ini akan kadaluarsa dalam <strong style="color:#00aaff;">1 jam</strong>.</p>
            <p style="color:#999;font-size:13px;">Jika Anda tidak meminta reset password, abaikan email ini.</p>
            <hr style="border-color:#1a3a5c;margin:24px 0;">
            <p style="color:#666;font-size:12px;text-align:center;">© ${global.developer} • ${global.siteName}</p>
        </div>`
    });
    logEmail('reset_password', to);
}

// ========== Send Welcome ==========
async function sendWelcome(to, name) {
    const transporter = getTransporter();
    await transporter.sendMail({
        from: global.smtpConfig.from,
        to,
        subject: `Selamat Datang di ${global.siteName}! 🌙`,
        html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0f;color:#e0e0e0;padding:30px;border-radius:12px;border:1px solid #1a3a5c;">
            <div style="text-align:center;margin-bottom:24px;">
                <h1 style="color:#00aaff;">🌙 ${global.siteName}</h1>
            </div>
            <h2 style="color:#fff;">Selamat datang, ${name}! 🎉</h2>
            <p>Akun Anda berhasil dibuat. Anda mendapatkan <strong style="color:#00aaff;">${global.trialDays} hari trial</strong> gratis!</p>
            <p>Mulai kelola bot WhatsApp Anda sekarang:</p>
            <div style="text-align:center;margin:32px 0;">
                <a href="${global.baseUrl}/dashboard" style="background:linear-gradient(135deg,#0066cc,#00aaff);color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold;">Ke Dashboard</a>
            </div>
            <hr style="border-color:#1a3a5c;margin:24px 0;">
            <p style="color:#666;font-size:12px;text-align:center;">© ${global.developer} • ${global.siteName}</p>
        </div>`
    });
    logEmail('welcome', to);
}

// ========== Send Payment Confirm ==========
async function sendPaymentConfirm(to, name, plan, expiry) {
    const transporter = getTransporter();
    await transporter.sendMail({
        from: global.smtpConfig.from,
        to,
        subject: `[${global.siteName}] Pembayaran Berhasil! 🎉`,
        html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0f;color:#e0e0e0;padding:30px;border-radius:12px;border:1px solid #1a3a5c;">
            <div style="text-align:center;margin-bottom:24px;">
                <h1 style="color:#00aaff;">🌙 ${global.siteName}</h1>
            </div>
            <h2 style="color:#fff;">Pembayaran Berhasil! ✅</h2>
            <p>Halo <strong>${name}</strong>, membership Anda telah aktif.</p>
            <div style="background:#0d1a2d;border:1px solid #1a3a5c;border-radius:8px;padding:16px;margin:20px 0;">
                <p style="margin:4px 0;"><strong>Paket:</strong> <span style="color:#00aaff;">${plan}</span></p>
                <p style="margin:4px 0;"><strong>Aktif hingga:</strong> <span style="color:#00aaff;">${new Date(expiry).toLocaleDateString('id-ID', { day:'numeric', month:'long', year:'numeric' })}</span></p>
            </div>
            <div style="text-align:center;margin:32px 0;">
                <a href="${global.baseUrl}/dashboard" style="background:linear-gradient(135deg,#0066cc,#00aaff);color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold;">Buka Dashboard</a>
            </div>
            <hr style="border-color:#1a3a5c;margin:24px 0;">
            <p style="color:#666;font-size:12px;text-align:center;">© ${global.developer} • ${global.siteName}</p>
        </div>`
    });
    logEmail('payment_confirm', to);
}

// ========== Admin Notification ==========
async function sendAdminNotif(subject, body) {
    const transporter = getTransporter();
    await transporter.sendMail({
        from: global.smtpConfig.from,
        to: global.smtpConfig.user,
        subject: `[ADMIN] ${subject}`,
        html: `<div style="font-family:Arial,sans-serif;padding:20px;"><h2>${subject}</h2><pre>${body}</pre></div>`
    });
}

// ========== Log Email ==========
function logEmail(type, to) {
    try {
        const logDir = path.join(__dirname, '..', 'data', 'logs');
        if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
        const entry = JSON.stringify({ timestamp: new Date().toISOString(), type, to }) + '\n';
        fs.appendFileSync(path.join(logDir, 'email.log'), entry);
    } catch (e) {}
}

module.exports = {
    sendResetPassword,
    sendWelcome,
    sendPaymentConfirm,
    sendAdminNotif
};
