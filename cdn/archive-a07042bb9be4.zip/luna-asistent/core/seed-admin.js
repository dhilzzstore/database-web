/**
 * core/seed-admin.js
 * Jalankan SEKALI untuk buat akun admin pertama:
 *   node core/seed-admin.js
 * © Kazama Dev (Dhilzz) 2026
 */

require('../settings.js');
const bcrypt  = require('bcrypt');
const readline = require('readline');

const { db } = require('./firebase');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(res => rl.question(q, res));

async function seedAdmin() {
    console.log('\n🌙 Luna Asistent - Admin Setup\n');

    const name     = await ask('Nama Admin   : ');
    const username = await ask('Username     : ');
    const email    = await ask('Email        : ');
    const password = await ask('Password     : ');

    if (!name || !username || !email || !password) {
        console.log('❌ Semua field wajib diisi!');
        rl.close(); process.exit(1);
    }
    if (password.length < 8) {
        console.log('❌ Password minimal 8 karakter!');
        rl.close(); process.exit(1);
    }

    // Cek sudah ada admin
    const snap = await db.collection('users').where('role', '==', 'admin').get();
    if (!snap.empty) {
        const overwrite = await ask('\n⚠️  Admin sudah ada. Tetap buat baru? (y/n): ');
        if (overwrite.toLowerCase() !== 'y') {
            console.log('Dibatalkan.'); rl.close(); process.exit(0);
        }
    }

    const hashed = await bcrypt.hash(password, 12);

    const adminData = {
        name,
        username: username.toLowerCase(),
        email: email.toLowerCase(),
        password: hashed,
        role: 'admin',
        slots: 999,
        membershipPlan: 'admin',
        membershipExpiry: new Date('2099-12-31'),
        trialUsed: true,
        banned: false,
        referralCode: 'ADMIN00',
        referralCount: 0,
        createdAt: new Date(),
        lastLogin: null
    };

    const ref = await db.collection('users').add(adminData);

    console.log('\n✅ Admin berhasil dibuat!');
    console.log('─────────────────────────────');
    console.log(`  UID      : ${ref.id}`);
    console.log(`  Nama     : ${name}`);
    console.log(`  Username : ${username}`);
    console.log(`  Email    : ${email}`);
    console.log(`  Role     : admin`);
    console.log('─────────────────────────────');
    console.log('\nLogin di: /auth/login');
    console.log('Admin dashboard: /admin\n');

    rl.close();
    process.exit(0);
}

seedAdmin().catch(e => {
    console.error('Error:', e.message);
    process.exit(1);
});
