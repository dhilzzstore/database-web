/**
 * settings.js - Luna Asistent Global Config Loader
 * Sambungkan config.json ke global variables
 * © Kazama Dev (Dhilzz)
 */

const fs = require('fs');
const path = require('path');

// ========== Load Config ==========
const configPath = path.join(__dirname, 'data', 'config.json');
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

// ========== Cloudflared & Server (TIDAK di config.json) ==========
global.cloudflared = {
    tokens: process.env.CLOUDFLARED_TOKEN || ''
};
global.port = process.env.PORT || 3000;
global.sessionSecret = process.env.SESSION_SECRET || 'luna-asistent-secret-2026';

// ========== Website ==========
global.siteName       = config.website.name;
global.siteDesc       = config.website.description;
global.siteTagline    = config.website.tagline;
global.siteLogo       = config.website.logo;
global.baseUrl        = config.website.baseUrl;
global.supportEmail   = config.website.supportEmail;
global.developer      = config.website.developer;

// ========== Maintenance ==========
global.maintenance        = config.maintenance;
global.maintenanceMessage = config.maintenanceMessage;
global.registrationOpen   = config.registrationOpen;

// ========== Membership ==========
global.membership   = config.membership;
global.slotPrice    = config.slotPrice;
global.defaultSlots = config.defaultSlots;
global.trialDays    = config.trialDays;
global.referralBonusDays = config.referralBonusDays;
global.vouchers     = config.vouchers;

// ========== Payment ==========
global.pakasirProject = config.payment.pakasirProject;
global.pakasirApikey  = config.payment.pakasirApikey;

// ========== SMTP ==========
global.smtpConfig = config.smtp;

// ========== OAuth ==========
global.oauthGoogle = config.oauth.google;
global.oauthGithub = config.oauth.github;

// ========== reCAPTCHA ==========
global.recaptchaSiteKey   = config.recaptcha.siteKey;
global.recaptchaSecretKey = config.recaptcha.secretKey;

// ========== Firebase ==========
global.firebaseConfig = config.firebase;

// ========== Social Media ==========
global.social = config.social;

// ========== Bot Config ==========
global.botConfig = config.botConfig;

// ========== i18n ==========
global.defaultLang    = config.i18n.defaultLang;
global.availableLangs = config.i18n.available;

// ========== Helper: Reload Config ==========
global.reloadConfig = function () {
    try {
        delete require.cache[require.resolve(configPath)];
        config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        // Re-assign semua global
        global.maintenance        = config.maintenance;
        global.maintenanceMessage = config.maintenanceMessage;
        global.registrationOpen   = config.registrationOpen;
        global.membership         = config.membership;
        global.slotPrice          = config.slotPrice;
        global.vouchers           = config.vouchers;
        global.pakasirProject     = config.payment.pakasirProject;
        global.pakasirApikey      = config.payment.pakasirApikey;
        global.smtpConfig         = config.smtp;
        global.botConfig          = config.botConfig;
        console.log('[ ✅ ] Config reloaded successfully');
        return true;
    } catch (e) {
        console.error('[ ✗ ] Failed to reload config:', e.message);
        return false;
    }
};

// ========== Helper: Save Config ==========
global.saveConfig = function (updates) {
    try {
        const current = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        const merged = deepMerge(current, updates);
        fs.writeFileSync(configPath, JSON.stringify(merged, null, 2));
        global.reloadConfig();
        return true;
    } catch (e) {
        console.error('[ ✗ ] Failed to save config:', e.message);
        return false;
    }
};

function deepMerge(target, source) {
    const output = Object.assign({}, target);
    if (isObject(target) && isObject(source)) {
        Object.keys(source).forEach(key => {
            if (isObject(source[key])) {
                if (!(key in target)) Object.assign(output, { [key]: source[key] });
                else output[key] = deepMerge(target[key], source[key]);
            } else {
                Object.assign(output, { [key]: source[key] });
            }
        });
    }
    return output;
}

function isObject(item) {
    return (item && typeof item === 'object' && !Array.isArray(item));
}

// Watch file perubahan manual
const file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});

module.exports = config;
