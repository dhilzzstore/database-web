/**
 * index.js - Luna Asistent Main Server
 * © Kazama Dev (Dhilzz) 2026
 */

require('./settings.js');

const express       = require('express');
const session       = require('express-session');
const path          = require('path');
const helmet        = require('helmet');
const rateLimit     = require('express-rate-limit');
const morgan        = require('morgan');
const cookieParser  = require('cookie-parser');
const flash         = require('connect-flash');
const passport      = require('passport');
const i18n          = require('i18n');
const chalk         = require('chalk');
const fs            = require('fs');

// ========== Init ==========
const app = express();

// ========== i18n Setup ==========
i18n.configure({
    locales: global.availableLangs || ['id', 'en'],
    directory: path.join(__dirname, 'core', 'locales'),
    defaultLocale: global.defaultLang || 'id',
    cookie: 'lang',
    queryParameter: 'lang',
    autoReload: true,
    syncFiles: true
});

// ========== View Engine ==========
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ========== Security ==========
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'", "https://www.google.com", "https://www.gstatic.com", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
            imgSrc: ["'self'", "data:", "https:", "blob:"],
            frameSrc: ["https://www.google.com"],
            connectSrc: ["'self'"]
        }
    }
}));

// Rate limiting global
const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    message: { success: false, message: 'Terlalu banyak request, coba lagi nanti.' }
});

// Rate limit ketat untuk auth
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 20,
    message: { success: false, message: 'Terlalu banyak percobaan login.' }
});

app.use(globalLimiter);

// ========== Middleware ==========
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: '1d',
    etag: false
}));

// Request logging
app.use(morgan('combined', {
    stream: {
        write: (msg) => {
            const logDir = path.join(__dirname, 'data', 'logs');
            if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
            fs.appendFileSync(path.join(logDir, 'access.log'), msg);
        }
    }
}));

// ========== Session ==========
app.use(session({
    secret: global.sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 hari
    }
}));

// ========== Flash & Passport ==========
app.use(flash());
require('./core/passport')(passport);
app.use(passport.initialize());
app.use(passport.session());

// ========== i18n ==========
app.use(i18n.init);
app.use((req, res, next) => {
    const lang = req.cookies.lang || req.query.lang || global.defaultLang;
    if (global.availableLangs.includes(lang)) {
        res.cookie('lang', lang, { maxAge: 365 * 24 * 60 * 60 * 1000 });
        req.setLocale(lang);
    }
    next();
});

// ========== Global Locals ==========
app.use((req, res, next) => {
    res.locals.user         = req.user || null;
    res.locals.isLoggedIn   = !!req.user;
    res.locals.isAdmin      = req.user?.role === 'admin';
    res.locals.maintenance  = global.maintenance;
    res.locals.siteName     = global.siteName;
    res.locals.siteTagline  = global.siteTagline;
    res.locals.developer    = global.developer;
    res.locals.social       = global.social;
    res.locals.recaptchaSiteKey = global.recaptchaSiteKey;
    res.locals.flash_success = req.flash('success');
    res.locals.flash_error   = req.flash('error');
    res.locals.flash_info    = req.flash('info');
    res.locals.currentLang   = req.getLocale();
    res.locals.availableLangs = global.availableLangs;
    res.locals.__           = res.__;
    next();
});

// ========== Maintenance Middleware ==========
const { maintenanceMiddleware } = require('./core/middleware');
app.use(maintenanceMiddleware);

// ========== Routes ==========
app.use('/',           require('./routes/index'));
app.use('/auth',       authLimiter, require('./routes/auth'));
app.use('/dashboard',  require('./routes/dashboard'));
app.use('/admin',      require('./routes/admin'));
app.use('/payment',    require('./routes/payment'));
app.use('/api',        require('./routes/api'));

// ========== Error Handling ==========
app.use((req, res, next) => {
    res.status(404).render('errors/404', {
        title: '404 - Halaman Tidak Ditemukan',
        url: req.originalUrl
    });
});

app.use((err, req, res, next) => {
    console.error(chalk.red('[ ✗ ] Server Error:'), err.stack);
    const status = err.status || 500;
    res.status(status).render(`errors/${status === 403 ? '403' : '500'}`, {
        title: `${status} - Terjadi Kesalahan`,
        error: process.env.NODE_ENV === 'development' ? err.message : 'Terjadi kesalahan pada server'
    });
});

// ========== Start Server ==========
async function startServer() {
    try {
        // Init Firebase
        require('./core/firebase');

        app.listen(global.port, () => {
            console.log(chalk.cyan.bold(`
╔══════════════════════════════════════╗
║   🌙 Luna Asistent - Server Ready   ║
╠══════════════════════════════════════╣
║  Port    : ${String(global.port).padEnd(27)}║
║  Mode    : ${String(process.env.NODE_ENV || 'development').padEnd(27)}║
║  Dev     : Kazama Dev (Dhilzz)       ║
╚══════════════════════════════════════╝`));
        });

        // Restore bot sessions yang sebelumnya connected
        setTimeout(async () => {
            try {
                const botManager = require('./core/botManager');
                await botManager.restoreSessions();
            } catch (e) {
                console.error(chalk.yellow('[ ⚠️ ] Bot restore sessions error:'), e.message);
            }
        }, 3000);

        // Start Cloudflare Tunnel jika token ada
        if (global.cloudflared.tokens) {
            const { startTunnel } = require('./tunnel');
            await startTunnel(global.cloudflared.tokens);
        }

    } catch (err) {
        console.error(chalk.red('[ ✗ ] Gagal start server:'), err.message);
        process.exit(1);
    }
}

startServer();
